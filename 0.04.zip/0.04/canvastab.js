

//				Canvas menu functions
function zoomFactor(){
	zoomF = (int(zoomValue.value()))/100;
	let sizeXF = sizeX.value()*zoomF;
	let sizeYF = sizeY.value()*zoomF;
	let oldZW = width;let oldZH = height;
	//loadPixels();
	zoomArt = get(0,0,width,height);
	resizeCanvas(sizeXF,sizeYF);
	oldW = width;
	oldH = height;
	//updatePixels();
	image(zoomArt,0,0,width,height);
	
	for(let i=0;i<layers.length;i++){
		let tmpZArt = layers[i][0].elt.surf.get(0,0,oldZW,oldZH);
		layers[i][0].elt.surf.resizeCanvas(sizeXF,sizeYF);
		layers[i][0].elt.surf.image(tmpZArt,0,0,width,height);
	}
	
	sizeBtn.style('color','black');
	sizeBtn.elt.textContent = "Size";
	widthBtn.position(surf.width/1+surf.position().x,surf.height/2);
	heightBtn.position(surf.width/2+surf.position().x,surf.height-2);
	resizeGrid();
}

function sizeBtnText(){
	sizeBtn.style('color','blue');
	sizeBtn.elt.textContent = "Resize";
}
function sizeBtnResize(){
	let sizeXF = sizeX.value()*zoomF;
	let sizeYF = sizeY.value()*zoomF;

	if(this === sizeBtn){
	loadPixels();
	resizeCanvas(sizeXF,sizeYF);
	for(let i=0;i<layers.length;i++){
		layers[i][0].elt.surf.loadPixels();
		layers[i][0].elt.surf.resizeCanvas(sizeXF,sizeYF);
		layers[i][0].elt.surf.updatePixels();
	}
	oldW = width;
	oldH = height;
	updatePixels();
	sizeBtn.style('color','black');
	sizeBtn.elt.textContent = "Size";
	widthBtn.position(surf.width/1+surf.position().x,surf.height/2);
	heightBtn.position(surf.width/2+surf.position().x,surf.height-2);
	resizeGrid();
	}
	if(this === sizeTextX){
		sizeBtn.style('color','black');
		sizeBtn.elt.textContent = "Size";
		sizeX.value(oldW/zoomF);
		sizeY.value(oldH/zoomF);
	}
	else if(this === sizeTextY){
		sizeBtn.style('color','black');
		sizeBtn.elt.textContent = "Size";
		sizeX.value(oldW/zoomF);
		sizeY.value(oldH/zoomF);
	}
}
function whBtns(mes){
	if(mes == 'wbtn'){
		loadPixels();
		resizeCanvas(widthBtn.position().x-8,height);
		/*for(let i=0;i<layers.length;i++){
			layers[i][0].elt.surf.loadPixels();
			layers[i][0].elt.surf.resizeCanvas(widthBtn.position().x-8,height);
			layers[i][0].elt.surf.updatePixels();
		}*/
		oldW = width;oldH = height;
		sizeX.value(oldW/zoomF);
		updatePixels();
		heightBtn.position(surf.width/2+surf.position().x,surf.height-2);
		resizeGrid();
	}
	else if(mes == 'hbtn'){
		if(height != 1){
		loadPixels();
		resizeCanvas(width,heightBtn.position().y-2);
		/*for(let i=0;i<layers.length;i++){
			layers[i][0].elt.surf.loadPixels();
			layers[i][0].elt.surf.resizeCanvas(width,heightBtn.position().y-2);
			layers[i][0].elt.surf.updatePixels();
		}*/
		oldW = width;oldH = height;
		sizeY.value(oldH/zoomF);
		updatePixels();
		widthBtn.position(surf.width+surf.position().x,surf.height/2);
		resizeGrid();}
	}
}

function setGrid(){
	pGrid = createGraphics(width,height,P2D);
	pGrid.position(surf.position().x,surf.position().y);
	pGrid.noSmooth();//pGrid.setAttributes('antialias', false);
	pGrid.strokeWeight(1);pGrid.stroke(color(gridColor.elt.style.backgroundColor));
	for(let i=0; i <= 100; i+=Number(gridStep.value()*zoomF)){
		pGrid.line(i,0,i,100);
		pGrid.line(0,i,100,i);
	}
	pGrid.show();
}
function resizeGrid(){
	pGrid.resizeCanvas(width,height);pGrid.redraw();
	//gridColor.elt.style.backgroundColor = color(curColor);
	//pGrid.stroke(color(gridColor.elt.style.backgroundColor));
	for(let i=0; i <= width; i+=Number(gridStep.value()*zoomF)){
		pGrid.line(i,0,i,height);
	}
	for(let i=0; i <= height; i+=Number(gridStep.value()*zoomF)){
		pGrid.line(0,i,width,i);
	}
}
function showGrid(){
	if(this.checked()){pGrid.show();}
	else{pGrid.hide();}
}
function recolorGrid(){
	gridColor.elt.style.backgroundColor = color(curColor);
	pGrid.stroke(color(curColor));
	resizeGrid();
}

function prepareClear(){
	if(clearChb.checked() == true){
		clearYN.elt.textContent = "Yes";}
	else{clearYN.elt.textContent = "No";}
}
function clearSurface(){
	if(clearChb.checked() == true && clearYN.elt.textContent == "Yes"){
		clear();
		clearYN.elt.textContent = "No";
	}
}

function setBackgroundColor(){
	backColor.style("background-image","linear-gradient(to right, "+"yellow 55%,"+color(curColor)+" 55%,"+
		color(curColor)+" 100%), url('backCell.png')");
	surf.style("background-image","linear-gradient("+color(curColor)+" 0%,"+
		color(curColor)+" 100%), url('backCell.png')");
}
function resetChecker(){surf.style('background-size','20px');}
function resizeChecker(){surf.style('background-size',checkerSize.value()+'px');}
function turnBorder(){
	if(canvasBorder.elt.style.backgroundColor == 'transparent'){
		canvasBorder.elt.style.backgroundColor = "orange";canvasBorder.html("Border on");
		surf.elt.style.outlineColor = 'pink';surf.elt.style.outlineWidth = '2px';
		surf.elt.style.outlineStyle = 'solid';
	}else if (canvasBorder.elt.style.backgroundColor == "orange"){
		canvasBorder.elt.style.backgroundColor = 'transparent';canvasBorder.html("Border off");
		surf.elt.style.outlineStyle = 'none';	
	}
}

function hwBtnTurn(){
	if(hwBtn.elt.style.backgroundColor == 'orange'){
		hwBtn.style('background-color','transparent');
		widthBtn.hide();heightBtn.hide();
	}else{
		hwBtn.style('background-color','orange');
		widthBtn.show();heightBtn.show();
	}
}

// loadPixels() ��� ��������� �������, � �� ������� �� �������,
				// ����� ���������� �� ����� ������
/*			
function zoomSurf(){ // ����������� ������������ �������(���������)
	//loadPixels();
	//resizeCanvas(200,200);
	//scale(1.5,1.5);
	oldArt = get(0,0,100,100);
	//loadPixels();
	//resizeCanvas(200,200);
	//updatePixels();
	set(100,100,oldArt);//scale(2,2);
	updatePixels();//scale(2,2);
	
}
function zoomSurf(){ // funny 'fractal' zooom
	oldArt = get();
	imageMode(CORNERS);
	image(oldArt,50,50,150,150);
}
*/