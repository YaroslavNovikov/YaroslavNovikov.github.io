

//				File menu functions
function loadFile(file){
	if(file.type === 'image'){
		tImg = createImg(file.data,'');//imga.show();
		tImg.remove();
	}else{tImg = null;}
	/*loadImage('download.png', tmpImg =>{ // FOR SERVER
		image(tmpImg,0,0); // tmpImg ��������� ������������� ����������� ����������
	});*/
}
function drawLoaded(){
	if(tImg){let tmpW = width;let tmpH = height;
		if(tImg.width > width){
			loadPixels();
			resizeCanvas(tImg.width,height);
			oldW = width;oldH = height;sizeX.value(oldW);sizeY.value(oldH);
			updatePixels();
			widthBtn.position(surf.width/1+surf.position().x,surf.height/2);
			heightBtn.position(surf.width/2+surf.position().x,surf.height-2);
			resizeGrid();
		}
		if(tImg.height > height){
			loadPixels();
			resizeCanvas(width,tImg.height);
			oldW = width;oldH = height;sizeX.value(oldW);sizeY.value(oldH);
			updatePixels();
			widthBtn.position(surf.width/1+surf.position().x,surf.height/2);
			heightBtn.position(surf.width/2+surf.position().x,surf.height-2);
			resizeGrid();
		}
		if(tmpW != width || tmpH != height){
			for(let i=0;i<layers.length;i++){
				layers[i][0].elt.surf.loadPixels();
				layers[i][0].elt.surf.resizeCanvas(width,height);
				layers[i][0].elt.surf.updatePixels();
			}
		}
		curLayer.image(tImg,0,0,tImg.width,tImg.height);
		tImg = null;
	}
}
function saveCanvasToFile(){
	saveCanvas(curLayer, "004canvas", 'png');
}
