let repColors = [];let pickingColToRep = false;let tmpColRep;let numId;let curRepCol = undefined;


function addRepCol(){
	//replacerMenu.elt.style.height = String(replacerMenu.size().height+80)+'px';
	replacerDiv.elt.style.height = String(replacerDiv.size().height+80)+'px';
	let tmpArr = [];let multiPosY = repColors.length-1;
	tmpArr[0] = createElement('label','');tmpArr[0].position(10,repColors[0][0].position().y-40+80*multiPosY);
	tmpArr[0].elt.style.width = "40px";tmpArr[0].elt.style.height = "40px";
	tmpArr[0].elt.style.backgroundColor = 'black';
	replacerDiv.child(tmpArr[0]);
	tmpArr[0].mouseClicked(pickColToRep);
	
	tmpArr[5] = createElement('label','');tmpArr[5].position(170,repColors[0][0].position().y-40+80*multiPosY);
	tmpArr[5].elt.style.width = "40px";tmpArr[5].elt.style.height = "40px";
	tmpArr[5].elt.style.backgroundColor = 'black';
	replacerDiv.child(tmpArr[5]);
	
	tmpArr[1] = createElement('label','R--------------------');tmpArr[1].position(49,repColors[0][1].position().y-40+80*multiPosY);
	tmpArr[1].elt.style.width = "122px";tmpArr[1].elt.style.height = "18px";
	tmpArr[1].style('background-color','yellow');tmpArr[1].style('opacity','0.5');
	replacerDiv.child(tmpArr[1]);tmpArr[1].mouseWheel(wheelRepCol);
	tmpArr[1].elt.onmousemove = changeRepRGBA;tmpArr[1].elt.r = 'R-';

	tmpArr[2] = createElement('label','G--------------------');tmpArr[2].position(49,repColors[0][2].position().y-40+80*multiPosY);
	tmpArr[2].elt.style.width = "122px";tmpArr[2].elt.style.height = "18px";
	tmpArr[2].style('background-color','yellow');tmpArr[2].style('opacity','0.5');
	replacerDiv.child(tmpArr[2]);tmpArr[2].mouseWheel(wheelRepCol);
	tmpArr[2].elt.onmousemove = changeRepRGBA;tmpArr[2].elt.r = 'G-';

	tmpArr[3] = createElement('label','B--------------------');tmpArr[3].position(49,repColors[0][3].position().y-40+80*multiPosY);
	tmpArr[3].elt.style.width = "122px";tmpArr[3].elt.style.height = "18px";
	tmpArr[3].style('background-color','yellow');tmpArr[3].style('opacity','0.5');
	replacerDiv.child(tmpArr[3]);tmpArr[3].mouseWheel(wheelRepCol);
	tmpArr[3].elt.onmousemove= changeRepRGBA;tmpArr[3].elt.r = 'B-';
	
	tmpArr[4] = createElement('label','A--------------------');tmpArr[4].position(69,repColors[0][4].position().y-40+80*multiPosY);
	tmpArr[4].elt.style.width = "122px";tmpArr[4].elt.style.height = "18px";
	tmpArr[4].style('background-color','yellow');tmpArr[4].style('opacity','0.5');
	replacerDiv.child(tmpArr[4]);tmpArr[4].mouseWheel(wheelRepCol);
	tmpArr[4].elt.onmousemove = changeRepRGBA;tmpArr[4].elt.r = 'A-';
	
	tmpArr[6] = createElement('label','res');tmpArr[6].position(197,tmpArr[4].position().y);
	tmpArr[6].style('background-color','white');
	tmpArr[6].style('padding-left','1px');tmpArr[6].style('padding-right','1px');
	replacerDiv.child(tmpArr[6]);tmpArr[6].elt.col = [];
	tmpArr[6].mousePressed(resetColor);
	
	tmpArr[5].elt.onmousedown = newColor;
	tmpArr[5].elt.newColor = newColor;
	repColors.push(tmpArr);
	repSliderStep();
}	
function delRepCol(){
	if(repColors.length > 1){
		repColors[repColors.length-1][0].remove();
		repColors[repColors.length-1][1].remove();
		repColors[repColors.length-1][2].remove();
		repColors[repColors.length-1][3].remove();
		repColors[repColors.length-1][4].remove();
		repColors[repColors.length-1][5].remove();
		repColors[repColors.length-1][6].remove();
		delete(repColors.pop());
		//replacerMenu.elt.style.height = String(replacerMenu.size().height-80)+'px';
		replacerDiv.elt.style.height = String(replacerDiv.size().height-80)+'px';
		repSliderStep();
	}
}



function pickColToRep(){
	if(pickingColToRep == false){
		tmpColRep = this;
		this.elt.style.outline = '5px yellow ridge';
		cursor('curs/repcolsim.png',-pipette.size().width,pipette.size().height);
		pickingColToRep = true;
		tmpTool = toolsRadio.value();
		toolsRadio.value("None");
	}
	else if(pickingColToRep ==  true){
		this.elt.style.outlineStyle = 'none';
		cursor("initial");
		pickingColToRep = false;
		toolsRadio.value(tmpTool);
	}
}

function changeRepRGBA(e){
if(mouseIsPressed && mouseButton === LEFT){
	let tmpCol = round((122-(this.parentElement.offsetLeft+this.offsetLeft+this.offsetWidth-e.x))*(255/122));

	if(tmpCol >= 0 && tmpCol <= 9){
		this.textContent = this.r+tmpCol+'-'.repeat(18);
	}
	else if(tmpCol >= 10 && tmpCol <= 15){
		this.textContent = this.r+tmpCol+'-'.repeat(16);
	}
	else if(tmpCol >= 16 && tmpCol <= 30){
		this.textContent = this.r+'-'+tmpCol+'-'.repeat(15);
	}
	else if(tmpCol >= 31 && tmpCol <= 45){
		this.textContent = this.r+'--'+tmpCol+'-'.repeat(14);
	}
	else if(tmpCol >= 46 && tmpCol <= 60){
		this.textContent = this.r+'---'+tmpCol+'-'.repeat(13);
	}
	else if(tmpCol >= 61 && tmpCol <= 75){
		this.textContent = this.r+'----'+tmpCol+'-'.repeat(12);
	}
	else if(tmpCol >= 76 && tmpCol <= 99){
		this.textContent = this.r+'-----'+tmpCol+'-'.repeat(11);
	}
	else if(tmpCol >= 100 && tmpCol <= 105){
		this.textContent = this.r+'-----'+tmpCol+'-'.repeat(10);
	}
	else if(tmpCol >= 106 && tmpCol <= 120){
		this.textContent = this.r+'------'+tmpCol+'-'.repeat(9);
	}
	else if(tmpCol >= 121 && tmpCol <= 135){
		this.textContent = this.r+'-------'+tmpCol+'-'.repeat(8);
	}
	else if(tmpCol >= 136 && tmpCol <= 150){
		this.textContent = this.r+'--------'+tmpCol+'-'.repeat(7);
	}
	else if(tmpCol >= 151 && tmpCol <= 165){
		this.textContent = this.r+'---------'+tmpCol+'-'.repeat(6);
	}
	else if(tmpCol >= 166 && tmpCol <= 180){
		this.textContent = this.r+'----------'+tmpCol+'-'.repeat(5);
	}
	else if(tmpCol >= 181 && tmpCol <= 195){
		this.textContent = this.r+'-----------'+tmpCol+'-'.repeat(4);
	}
	else if(tmpCol >= 196 && tmpCol <= 210){
		this.textContent = this.r+'------------'+tmpCol+'-'.repeat(3);
	}
	else if(tmpCol >= 211 && tmpCol <= 225){
		this.textContent = this.r+'-------------'+tmpCol+'-'.repeat(2);
	}
	else if(tmpCol >= 226 && tmpCol <= 240){
		this.textContent = this.r+'--------------'+tmpCol+'-'.repeat(1);
	}
	else if(tmpCol >= 241 && tmpCol <= 255){
		this.textContent = this.r+ '---------------'+tmpCol;
	}
	if(this.r == 'R-'){
		let tmpColor = color(this.previousSibling.style.backgroundColor).levels;
		this.previousSibling.style.backgroundColor = color(tmpCol,tmpColor[1],tmpColor[2],tmpColor[3]);
		if(liveColRep.elt.style.backgroundColor == 'red' && autoColRep.elt.style.backgroundColor == 'red'){
			this.previousSibling.newColor();
		}
	}
	else if(this.r == 'G-'){
		let tmpColor = color(this.previousSibling.previousSibling.style.backgroundColor).levels;
		this.previousSibling.previousSibling.style.backgroundColor = color(tmpColor[0],tmpCol,tmpColor[2],tmpColor[3]);
		if(liveColRep.elt.style.backgroundColor == 'red' && autoColRep.elt.style.backgroundColor == 'red'){
			this.previousSibling.previousSibling.newColor();
		}	
	}
	else if(this.r == 'B-'){
		let tmpColor = color(this.previousSibling.previousSibling.previousSibling.style.backgroundColor).levels;
		this.previousSibling.previousSibling.previousSibling.style.backgroundColor = color(tmpColor[0],tmpColor[1],tmpCol,tmpColor[3]);
		if(liveColRep.elt.style.backgroundColor == 'red' && autoColRep.elt.style.backgroundColor == 'red'){
			this.previousSibling.previousSibling.previousSibling.newColor();
		}		
	}
	else if(this.r == 'A-'){
		let tmpColor = color(this.previousSibling.previousSibling.previousSibling.previousSibling.style.backgroundColor).levels;
		this.previousSibling.previousSibling.previousSibling.previousSibling.style.backgroundColor = color(tmpColor[0],tmpColor[1],tmpColor[2],tmpCol);	
		if(liveColRep.elt.style.backgroundColor == 'red' && autoColRep.elt.style.backgroundColor == 'red'){
			this.previousSibling.previousSibling.previousSibling.previousSibling.newColor();
		}		
	}
}}

function getRepRGBA(numLabel, tmpColorIndex){
	numLabel.textContent = tmpColorIndex;
	
	if(numLabel.textContent >= 0 && numLabel.textContent <= 9){
		numLabel.textContent = numLabel.r+numLabel.textContent+'-'.repeat(18);
	}
	else if(numLabel.textContent >= 10 && numLabel.textContent <= 15){
		numLabel.textContent = numLabel.r+numLabel.textContent+'-'.repeat(16);
	}
	else if(numLabel.textContent >= 16 && numLabel.textContent <= 30){
		numLabel.textContent = numLabel.r+'-'+numLabel.textContent+'-'.repeat(15);
	}
	else if(numLabel.textContent >= 31 && numLabel.textContent <= 45){
		numLabel.textContent = numLabel.r+'--'+numLabel.textContent+'-'.repeat(14);
	}
	else if(numLabel.textContent >= 46 && numLabel.textContent <= 60){
		numLabel.textContent = numLabel.r+'---'+numLabel.textContent+'-'.repeat(13);
	}
	else if(numLabel.textContent >= 61 && numLabel.textContent <= 75){
		numLabel.textContent = numLabel.r+'----'+numLabel.textContent+'-'.repeat(12);
	}
	else if(numLabel.textContent >= 76 && numLabel.textContent <= 99){
		numLabel.textContent = numLabel.r+'-----'+numLabel.textContent+'-'.repeat(11);
	}
	else if(numLabel.textContent >= 100 && numLabel.textContent <= 105){
		numLabel.textContent = numLabel.r+'-----'+numLabel.textContent+'-'.repeat(10);
	}
	else if(numLabel.textContent >= 106 && numLabel.textContent <= 120){
		numLabel.textContent = numLabel.r+'------'+numLabel.textContent+'-'.repeat(9);
	}
	else if(numLabel.textContent >= 121 && numLabel.textContent <= 135){
		numLabel.textContent = numLabel.r+'-------'+numLabel.textContent+'-'.repeat(8);
	}
	else if(numLabel.textContent >= 136 && numLabel.textContent <= 150){
		numLabel.textContent = numLabel.r+'--------'+numLabel.textContent+'-'.repeat(7);
	}
	else if(numLabel.textContent >= 151 && numLabel.textContent <= 165){
		numLabel.textContent = numLabel.r+'---------'+numLabel.textContent+'-'.repeat(6);
	}
	else if(numLabel.textContent >= 166 && numLabel.textContent <= 180){
		numLabel.textContent = numLabel.r+'----------'+numLabel.textContent+'-'.repeat(5);
	}
	else if(numLabel.textContent >= 181 && numLabel.textContent <= 195){
		numLabel.textContent = numLabel.r+'-----------'+numLabel.textContent+'-'.repeat(4);
	}
	else if(numLabel.textContent >= 196 && numLabel.textContent <= 210){
		numLabel.textContent = numLabel.r+'------------'+numLabel.textContent+'-'.repeat(3);
	}
	else if(numLabel.textContent >= 211 && numLabel.textContent <= 225){
		numLabel.textContent = numLabel.r+'-------------'+numLabel.textContent+'-'.repeat(2);
	}
	else if(numLabel.textContent >= 226 && numLabel.textContent <= 240){
		numLabel.textContent = numLabel.r+'--------------'+numLabel.textContent+'-'.repeat(1);
	}
	else if(numLabel.textContent >= 241 && numLabel.textContent <= 255){
		numLabel.textContent = numLabel.r+ '---------------'+numLabel.textContent;
	}
}

function wheelRepCol(event){
	let tmpCol;
	if(this.elt.r == 'R-'){
		let tmpColor = color(this.elt.previousSibling.style.backgroundColor).levels;
		tmpCol = tmpColor[0];
		tmpCol -= event.deltaY/100;
		this.elt.previousSibling.style.backgroundColor = color(tmpCol,tmpColor[1],tmpColor[2],tmpColor[3]);
	}
	else if(this.elt.r == 'G-'){
		let tmpColor = color(this.elt.previousSibling.previousSibling.style.backgroundColor).levels;
		tmpCol = tmpColor[1];
		tmpCol -= event.deltaY/100;
		this.elt.previousSibling.previousSibling.style.backgroundColor = color(tmpColor[0],tmpCol,tmpColor[2],tmpColor[3]);
	}
	else if(this.elt.r == 'B-'){
		let tmpColor = color(this.elt.previousSibling.previousSibling.previousSibling.style.backgroundColor).levels;
		tmpCol = tmpColor[2];
		tmpCol -= event.deltaY/100;
		this.elt.previousSibling.previousSibling.previousSibling.style.backgroundColor = color(tmpColor[0],tmpColor[1],tmpCol,tmpColor[3]);
	}
	else if(this.elt.r == 'A-'){
		let tmpColor = color(this.elt.previousSibling.previousSibling.previousSibling.previousSibling.style.backgroundColor).levels;
		tmpCol = tmpColor[3];
		tmpCol -= event.deltaY/100;
		this.elt.previousSibling.previousSibling.previousSibling.previousSibling.style.backgroundColor = color(tmpColor[0],tmpColor[1],tmpColor[2],tmpCol);
	}
	if(tmpCol >= 0 && tmpCol <= 9){
		this.elt.textContent = this.elt.r+tmpCol+'-'.repeat(18);
	}
	else if(tmpCol >= 10 && tmpCol <= 15){
		this.elt.textContent = this.elt.r+tmpCol+'-'.repeat(16);
	}
	else if(tmpCol >= 16 && tmpCol <= 30){
		this.elt.textContent = this.elt.r+'-'+tmpCol+'-'.repeat(15);
	}
	else if(tmpCol >= 31 && tmpCol <= 45){
		this.elt.textContent = this.elt.r+'--'+tmpCol+'-'.repeat(14);
	}
	else if(tmpCol >= 46 && tmpCol <= 60){
		this.elt.textContent = this.elt.r+'---'+tmpCol+'-'.repeat(13);
	}
	else if(tmpCol >= 61 && tmpCol <= 75){
		this.elt.textContent = this.elt.r+'----'+tmpCol+'-'.repeat(12);
	}
	else if(tmpCol >= 76 && tmpCol <= 99){
		this.elt.textContent = this.elt.r+'-----'+tmpCol+'-'.repeat(11);
	}
	else if(tmpCol >= 100 && tmpCol <= 105){
		this.elt.textContent = this.elt.r+'-----'+tmpCol+'-'.repeat(10);
	}
	else if(tmpCol >= 106 && tmpCol <= 120){
		this.elt.textContent = this.elt.r+'------'+tmpCol+'-'.repeat(9);
	}
	else if(tmpCol >= 121 && tmpCol <= 135){
		this.elt.textContent = this.elt.r+'-------'+tmpCol+'-'.repeat(8);
	}
	else if(tmpCol >= 136 && tmpCol <= 150){
		this.elt.textContent = this.elt.r+'--------'+tmpCol+'-'.repeat(7);
	}
	else if(tmpCol >= 151 && tmpCol <= 165){
		this.elt.textContent = this.elt.r+'---------'+tmpCol+'-'.repeat(6);
	}
	else if(tmpCol >= 166 && tmpCol <= 180){
		this.elt.textContent = this.elt.r+'----------'+tmpCol+'-'.repeat(5);
	}
	else if(tmpCol >= 181 && tmpCol <= 195){
		this.elt.textContent = this.elt.r+'-----------'+tmpCol+'-'.repeat(4);
	}
	else if(tmpCol >= 196 && tmpCol <= 210){
		this.elt.textContent = this.elt.r+'------------'+tmpCol+'-'.repeat(3);
	}
	else if(tmpCol >= 211 && tmpCol <= 225){
		this.elt.textContent = this.elt.r+'-------------'+tmpCol+'-'.repeat(2);
	}
	else if(tmpCol >= 226 && tmpCol <= 240){
		this.elt.textContent = this.elt.r+'--------------'+tmpCol+'-'.repeat(1);
	}
	else if(tmpCol >= 241 && tmpCol <= 255){
		this.elt.textContent = this.elt.r+ '---------------'+tmpCol;
	}
}

function turnResetAutoLive(){
	if(this.elt.style.backgroundColor == 'white'){this.elt.style.backgroundColor = 'red';
		if(this === numsColRep){
			for(let i=0;i<repColors.length;i++){
				repColors[i][1].mousePressed(posRepColNum);repColors[i][2].mousePressed(posRepColNum);
				repColors[i][3].mousePressed(posRepColNum);repColors[i][4].mousePressed(posRepColNum);
			}
		}
	}
	else if(this.elt.style.backgroundColor == 'red'){this.elt.style.backgroundColor = 'white';}
}

function newColor(){
	if(pickingColToRep == true && this.previousSibling.style.outlineWidth == '5px'){
		curLayer.loadPixels();
		let prevColor = color(this.previousSibling.style.backgroundColor).levels;
		let tmpR = color(this.style.backgroundColor).levels[0];
		let tmpG = color(this.style.backgroundColor).levels[1];
		let tmpB = color(this.style.backgroundColor).levels[2];
		let tmpA = color(this.style.backgroundColor).levels[3];
		for(let i=0;i<width*4*height;i+=4){
			if(curLayer.pixels[i] == prevColor[0] && curLayer.pixels[i+1] == prevColor[1] && curLayer.pixels[i+2] == prevColor[2] && curLayer.pixels[i+3] == prevColor[3]){
				curLayer.pixels[i] = tmpR;
				curLayer.pixels[i+1] = tmpG;
				curLayer.pixels[i+2] = tmpB;
				curLayer.pixels[i+3] = tmpA;
			}
		}
		curLayer.updatePixels();
		if(autoColRep.elt.style.backgroundColor == 'red'){
			this.previousSibling.style.backgroundColor = color(this.style.backgroundColor);//String(color(tmpR,tmpG,tmpB,tmpA));
		}
	}
}

function resetColor(){//*********FIX LATER************
	if(resetColRep.elt.style.backgroundColor == 'red'){
		tmpCol = color(this.elt.col).levels;
		this.elt.previousSibling.previousSibling.previousSibling.previousSibling.previousSibling.style.backgroundColor = color(this.elt.col);
		this.elt.previousSibling.previousSibling.previousSibling.previousSibling.previousSibling.newColor();
		this.elt.previousSibling.previousSibling.previousSibling.previousSibling.previousSibling.previousSibling.style.backgroundColor = color(this.elt.col);
		getRepRGBA(this.elt.previousSibling.previousSibling.previousSibling.previousSibling,tmpCol[0]);
		getRepRGBA(this.elt.previousSibling.previousSibling.previousSibling,tmpCol[1]);
		getRepRGBA(this.elt.previousSibling.previousSibling,tmpCol[2]);
		getRepRGBA(this.elt.previousSibling,tmpCol[3]);
		
	}
}


function posRepColNum(){
	inputColRep.position(this.position().x+inputColRep.width,this.position().y);
	inputColRep.show();
	if(this.elt.r == 'R-'){
		inputColRep.value(color(this.elt.previousSibling.style.backgroundColor).levels[0]);
	}else if(this.elt.r == 'G-'){
		inputColRep.value(color(this.elt.previousSibling.previousSibling.style.backgroundColor).levels[1]);
	}else if(this.elt.r == 'B-'){
		inputColRep.value(color(this.elt.previousSibling.previousSibling.previousSibling.style.backgroundColor).levels[2]);
	}else if(this.elt.r == 'A-'){
		inputColRep.value(color(this.elt.previousSibling.previousSibling.previousSibling.previousSibling.style.backgroundColor).levels[3]);
	}numId = this.elt;
}
function useRepColNum(){
	getRepRGBA(numId,inputColRep.value());
	if(numId.r == 'R-'){
		let oldCol = color(numId.previousSibling.style.backgroundColor).levels;
		numId.previousSibling.style.backgroundColor = color(inputColRep.value(),oldCol[1],oldCol[2],oldCol[3]);
	}
	else if(numId.r == 'G-'){
		let oldCol = color(numId.previousSibling.previousSibling.style.backgroundColor).levels;
		numId.previousSibling.previousSibling.style.backgroundColor = color(oldCol[0],inputColRep.value(),oldCol[2],oldCol[3]);
	}
	else if(numId.r == 'B-'){
		let oldCol = color(numId.previousSibling.previousSibling.previousSibling.style.backgroundColor).levels;
		numId.previousSibling.previousSibling.previousSibling.style.backgroundColor = color(oldCol[0],oldCol[1],inputColRep.value(),oldCol[3]);
	}	
	else if(numId.r == 'A-'){
		let oldCol = color(numId.previousSibling.previousSibling.previousSibling.previousSibling.style.backgroundColor).levels;
		numId.previousSibling.previousSibling.previousSibling.previousSibling.style.backgroundColor = color(oldCol[0],oldCol[1],oldCol[2],Number(inputColRep.value()));
	}	
}
function hideRepColNum(){
	inputColRep.hide();//console.log(inputColRep.value());
}

//				Sliider functions
function repSliderStep(){
	repSlider.elt.max = repColors.length;
}
function replacerSlide(){
	replacerDiv.elt.style.top = replacerDiv.elt.zH - (80*repSlider.elt.value) + 'px';
}
function hideReplacerDiv(){
	if(this.elt.style.backgroundColor == 'white'){
		this.elt.style.backgroundColor = 'red';replacerDiv.hide();
	}else if(this.elt.style.backgroundColor == 'red'){
		this.elt.style.backgroundColor = 'white';replacerDiv.show();
	}
}



/*
function newColor(){
	if(pickingColToRep == true && this.elt.previousSibling.style.outlineWidth == '5px'){
		loadPixels();
		let prevColor = color(this.elt.previousSibling.style.backgroundColor).levels;
		let tmpR = color(this.elt.style.backgroundColor).levels[0];
		let tmpG = color(this.elt.style.backgroundColor).levels[1];
		let tmpB = color(this.elt.style.backgroundColor).levels[2];
		let tmpA = color(this.elt.style.backgroundColor).levels[3];
		for(let i=0;i<width*4*height;i+=4){
			if(pixels[i] == prevColor[0] && pixels[i+1] == prevColor[1] && pixels[i+2] == prevColor[2] && pixels[i+3] == prevColor[3]){
				pixels[i] = tmpR;
				pixels[i+1] = tmpG;
				pixels[i+2] = tmpB;
				pixels[i+3] = tmpA;
			}
		}
		updatePixels();
		if(autoColRep.elt.style.backgroundColor == 'red'){
			this.elt.previousSibling.style.backgroundColor = color(this.elt.style.backgroundColor);//String(color(tmpR,tmpG,tmpB,tmpA));
		}
	}
}*/
/*
function changeRepRGBA(e){
	let tmpCol = round((122-(this.elt.parentElement.offsetLeft+this.elt.offsetLeft+this.elt.offsetWidth-e.x))*(255/122));

	if(tmpCol >= 0 && tmpCol <= 9){
		this.elt.textContent = this.elt.r+tmpCol+'-'.repeat(18);
	}
	else if(tmpCol >= 10 && tmpCol <= 15){
		this.elt.textContent = this.elt.r+tmpCol+'-'.repeat(16);
	}
	else if(tmpCol >= 16 && tmpCol <= 30){
		this.elt.textContent = this.elt.r+'-'+tmpCol+'-'.repeat(15);
	}
	else if(tmpCol >= 31 && tmpCol <= 45){
		this.elt.textContent = this.elt.r+'--'+tmpCol+'-'.repeat(14);
	}
	else if(tmpCol >= 46 && tmpCol <= 60){
		this.elt.textContent = this.elt.r+'---'+tmpCol+'-'.repeat(13);
	}
	else if(tmpCol >= 61 && tmpCol <= 75){
		this.elt.textContent = this.elt.r+'----'+tmpCol+'-'.repeat(12);
	}
	else if(tmpCol >= 76 && tmpCol <= 99){
		this.elt.textContent = this.elt.r+'-----'+tmpCol+'-'.repeat(11);
	}
	else if(tmpCol >= 100 && tmpCol <= 105){
		this.elt.textContent = this.elt.r+'-----'+tmpCol+'-'.repeat(10);
	}
	else if(tmpCol >= 106 && tmpCol <= 120){
		this.elt.textContent = this.elt.r+'------'+tmpCol+'-'.repeat(9);
	}
	else if(tmpCol >= 121 && tmpCol <= 135){
		this.elt.textContent = this.elt.r+'-------'+tmpCol+'-'.repeat(8);
	}
	else if(tmpCol >= 136 && tmpCol <= 150){
		this.elt.textContent = this.elt.r+'--------'+tmpCol+'-'.repeat(7);
	}
	else if(tmpCol >= 151 && tmpCol <= 165){
		this.elt.textContent = this.elt.r+'---------'+tmpCol+'-'.repeat(6);
	}
	else if(tmpCol >= 166 && tmpCol <= 180){
		this.elt.textContent = this.elt.r+'----------'+tmpCol+'-'.repeat(5);
	}
	else if(tmpCol >= 181 && tmpCol <= 195){
		this.elt.textContent = this.elt.r+'-----------'+tmpCol+'-'.repeat(4);
	}
	else if(tmpCol >= 196 && tmpCol <= 210){
		this.elt.textContent = this.elt.r+'------------'+tmpCol+'-'.repeat(3);
	}
	else if(tmpCol >= 211 && tmpCol <= 225){
		this.elt.textContent = this.elt.r+'-------------'+tmpCol+'-'.repeat(2);
	}
	else if(tmpCol >= 226 && tmpCol <= 240){
		this.elt.textContent = this.elt.r+'--------------'+tmpCol+'-'.repeat(1);
	}
	else if(tmpCol >= 241 && tmpCol <= 255){
		this.elt.textContent = this.elt.r+ '---------------'+tmpCol;
	}
	if(this.elt.r == 'R-'){
		let tmpColor = color(this.elt.previousSibling.style.backgroundColor).levels;
		this.elt.previousSibling.style.backgroundColor = color(tmpCol,tmpColor[1],tmpColor[2],tmpColor[3]);
	}
	else if(this.elt.r == 'G-'){
		let tmpColor = color(this.elt.previousSibling.previousSibling.style.backgroundColor).levels;
		this.elt.previousSibling.previousSibling.style.backgroundColor = color(tmpColor[0],tmpCol,tmpColor[2],tmpColor[3]);
	}
	else if(this.elt.r == 'B-'){
		let tmpColor = color(this.elt.previousSibling.previousSibling.previousSibling.style.backgroundColor).levels;
		this.elt.previousSibling.previousSibling.previousSibling.style.backgroundColor = color(tmpColor[0],tmpColor[1],tmpCol,tmpColor[3]);
	}
	else if(this.elt.r == 'A-'){
		let tmpColor = color(this.elt.previousSibling.previousSibling.previousSibling.previousSibling.style.backgroundColor).levels;
		this.elt.previousSibling.previousSibling.previousSibling.previousSibling.style.backgroundColor = color(tmpColor[0],tmpColor[1],tmpColor[2],tmpCol);	
	}
}*/
/*
function slideR1(e){
	let opa = e.x - (e.srcElement.offsetParent.offsetLeft+e.srcElement.offsetLeft);
	console.log(round(opa*(255/96)));
	//console.log(e.srcElement.offsetParent.offsetLeft+e.srcElement.offsetLeft+this.elt.offsetWidth);
}*/
