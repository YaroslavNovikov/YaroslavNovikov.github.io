let surf, pGrid;
let tImg;let zoomArt;
var img;



function setup(){
	inits();
	
	//stroke(pColor);
	//img.loadPixels();
	//for(let i = 0; i < img.width; i++){
		//img.set(i,0,color(255-(50*i)));
		//point(i,0);
	//}
	//for(let j=0;j<img.height;j++){
   //   for(let)
    //console.log(j);
    //if(j%2 == 0){
      //img.set(j,0,color(200,200,40));
    //}else{
      //img.set(j,0,color(20,50,120));
//  }
    
	//}
 /* for(let i = 0; i < img.width; i++){
		//let po = 1;
		for(let j = 0; j < img.height; j++){			
			img.set(i,j,color(0,90,102));
			//img.set(10,j,color(90,90,10));
			img.set(i+i,j,color(100,0,20));
		}
	}*/
	//img.updatePixels();	

}

function draw() {
	//background(140,140,60);
}


function mouseDragged(e){
	if(fileBtn.isDrag == true){
		//console.log(e.toElement.isDrago == 3);
		fileBtn.position(mouseX,mouseY);
		if(fileBtn.position().y < 0){fileBtn.position(fileBtn.position().x,0);}
		fileMenu.position(fileBtn.position().x,fileBtn.position().y+fileBtn.height);
	//				dragging 'children' union
		if(unitedDrag == true){
			for(let i=0;i<masso.length;i++){
				if(masso[i] != fileBtn){
					masso[i].position(masso[0].position().x+masso[i].unitedF[0],masso[0].position().y);
					masso[i].menu.position(masso[0].position().x,masso[0].position().y+masso[i].height+masso[i].unitedF[1]);
				}
			}
		}//		highlight masso[0] for union
		if(masso.length == 0){
			for(let i=0;i<menuBtns.length;i++){
				if(fileBtn != menuBtns[i] && dist(fileBtn.position().x,fileBtn.position().y,menuBtns[i].position().x,menuBtns[i].position().y) < 40){
					menuBtns[i].addClass('toUnionLight');
				}
				if(menuBtns[i].hasClass('toUnionLight') && fileBtn != menuBtns[i] && dist(fileBtn.position().x,fileBtn.position().y,menuBtns[i].position().x,menuBtns[i].position().y) > 40){
					menuBtns[i].removeClass('toUnionLight');
				}				
			}
		}
	}
	else if(canvasBtn.isDrag == true){
		canvasBtn.position(mouseX,mouseY);
		if(canvasBtn.position().y < 0){canvasBtn.position(canvasBtn.position().x,0);}
		canvasMenu.position(canvasBtn.position().x,canvasBtn.position().y+canvasBtn.height);
	//				dragging 'children' union
		if(unitedDrag == true){
			for(let i=0;i<masso.length;i++){
				if(masso[i] != canvasBtn){
					masso[i].position(masso[0].position().x+masso[i].unitedF[0],masso[0].position().y);
					masso[i].menu.position(masso[0].position().x,masso[0].position().y+masso[i].height+masso[i].unitedF[1]);
				}
			}
		}
	}
	else if(colorBtn.isDrag == true){
		colorBtn.position(mouseX,mouseY);
		if(colorBtn.position().y < 0){colorBtn.position(colorBtn.position().x,0);}
		colorMenu.position(colorBtn.position().x,colorBtn.position().y+colorBtn.height);
	//				dragging 'children' union
		if(unitedDrag == true){
			for(let i=0;i<masso.length;i++){
				if(masso[i] != colorBtn){
					masso[i].position(masso[0].position().x+masso[i].unitedF[0],masso[0].position().y);
					masso[i].menu.position(masso[0].position().x,masso[0].position().y+masso[i].height+masso[i].unitedF[1]);
				}
			}
		}
	}
	else if(toolsBtn.isDrag == true){
		toolsBtn.position(mouseX,mouseY);
		if(toolsBtn.position().y < 0){toolsBtn.position(toolsBtn.position().x,0);}
		toolsMenu.position(toolsBtn.position().x,toolsBtn.position().y+toolsBtn.height);		
	//				dragging 'children' union
		if(unitedDrag == true){
			for(let i=0;i<masso.length;i++){
				if(masso[i] != toolsBtn){
					masso[i].position(masso[0].position().x+masso[i].unitedF[0],masso[0].position().y);
					masso[i].menu.position(masso[0].position().x,masso[0].position().y+masso[i].height+masso[i].unitedF[1]);
				}
			}
		}
	}
	else if(replacerBtn.isDrag == true){
		replacerBtn.position(mouseX,mouseY);
		if(replacerBtn.position().y < 0){replacerBtn.position(replacerBtn.position().x,0);}
		replacerMenu.position(replacerBtn.position().x,replacerBtn.position().y+replacerBtn.height);
		if(pinRepDiv.elt.style.backgroundColor == 'red'){
			replacerDiv.position(replacerMenu.position().x,replacerMenu.position().y+replacerMenu.height);
		}
	//				dragging 'children' union
		if(unitedDrag == true){
			for(let i=0;i<masso.length;i++){
				if(masso[i] != replacerBtn){
					masso[i].position(masso[0].position().x+masso[i].unitedF[0],masso[0].position().y);
					masso[i].menu.position(masso[0].position().x,masso[0].position().y+masso[i].height+masso[i].unitedF[1]);
				}
			}
		}
	}
	else if(widthBtn.elt.isDrag == true){
		let btn = 'wbtn';
		widthBtn.position(mouseX-widthBtn.size().width/4,widthBtn.position().y);whBtns('wbtn');
	}
	else if(heightBtn.elt.isDrag == true){
		let btn = 'hbtn';
		heightBtn.position(heightBtn.position().x,mouseY-heightBtn.size().width/2);whBtns('hbtn');
	}
}
function mouseReleased(){
	if(widthBtn.elt.isDrag == true && dist(widthBtn.position().x,widthBtn.position().y,mouseX,mouseY) > 100){widthBtn.elt.isDrag = false;}
	if(heightBtn.elt.isDrag == true && dist(heightBtn.position().x,heightBtn.position().y,mouseX,mouseY) > 100){heightBtn.elt.isDrag = false;}
}


//				Drawing functions
function drawingOnCanvas(){
	//if(toolsRadio.value() == "Fill"){popo.position(mouseX+9,mouseY-24);}
	if(mouseIsPressed && mouseButton === LEFT){
		if(curColTool != undefined && curColTool.elt.alt == "Pipette"){
			let tmpColor = curLayer.get(mouseX,mouseY);
			sliderR.value(tmpColor[0]);sliderG.value(tmpColor[1]);sliderB.value(tmpColor[2]);sliderA.value(tmpColor[3]);
			curColor = [sliderR.value(),sliderG.value(),sliderB.value(),sliderA.value()];
			curColPicker.value("#"+hex(sliderR.value(),2)+hex(sliderG.value(),2)+hex(sliderB.value(),2));
			curColRect.style("background-image", "linear-gradient(to right,"+
				color(curColor[0],curColor[1],curColor[2])+" 50%,"+ color(curColor)+" 50%)");
			curColTool = undefined;pipette.removeClass('icon_Light');toolsRadio.value(tmpTool);cursor("initial");pickToSet.hide();
			numR.value(curColor[0]);numG.value(curColor[1]);numB.value(curColor[2]);numA.value(curColor[3]);
		}
		else if(curColTool != undefined && curColTool.elt.alt == "Fastrepl"){
			fastReplaceColor();cursor("initial");
		}
		else if(toolsRadio.value() == "Pen"){pen();}
		else if(toolsRadio.value() == "Erase"){pen();}
		else if(toolsRadio.value() == "Fill"){toolsRadio.value("None");fillit();}
		
		else if(pickingColToRep == true){
			let tmpColor = curLayer.get(mouseX,mouseY);
			getRepRGBA(tmpColRep.elt.nextSibling.nextSibling,tmpColor[0]);
			getRepRGBA(tmpColRep.elt.nextSibling.nextSibling.nextSibling,tmpColor[1]);
			getRepRGBA(tmpColRep.elt.nextSibling.nextSibling.nextSibling.nextSibling,tmpColor[2]);
			getRepRGBA(tmpColRep.elt.nextSibling.nextSibling.nextSibling.nextSibling.nextSibling,tmpColor[3]);
			tmpColRep.elt.style.backgroundColor = color(tmpColor);
			tmpColRep.elt.nextSibling.style.backgroundColor = color(tmpColor);
			tmpColRep.elt.nextSibling.nextSibling.nextSibling.nextSibling.nextSibling.nextSibling.col = tmpColor;
			tmpColRep.elt.nextSibling.nextSibling.nextSibling.nextSibling.nextSibling.nextSibling.style.border = '1px solid';
			tmpColRep.elt.nextSibling.nextSibling.nextSibling.nextSibling.nextSibling.nextSibling.style.backgroundColor = color(tmpColor);
		}
	}
}
function stopDrawingCanvas(){
	if(toolsRadio.selected() == 'Pen' && penTypeRadio.selected() == 'shot'){penShot = false;}
}


