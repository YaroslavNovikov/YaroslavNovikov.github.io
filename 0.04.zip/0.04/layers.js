let curLayer;let curMini = undefined; let layers = [];let operLayer = undefined;let operParam = undefined;




function addLayer(){
	let tmpStep = 60*layers.length;
	let tmpLayer = [];
	let tmpName = createElement('label','Layer '+layers.length);
	tmpName.position(50,20+tmpStep);tmpName.elt.style.backgroundColor = 'white';
	tmpName.style('padding-left','2px');tmpName.style('padding-right','2px');
		tmpName.elt.surf = createGraphics(width,height,P2D);
		tmpName.elt.surf.noSmooth();
		tmpName.elt.surf.position(surf.position().x,surf.position().y);
		tmpName.elt.surf.elt.style.zIndex = 0;//Number(surf.elt.style.zIndex)-layers.length;
		tmpName.elt.surf.show();tmpName.elt.surf.layerId = layers.length;
		tmpName.elt.surf.mousePressed(drawingOnCanvas);
		tmpName.elt.surf.mouseMoved(drawingOnCanvas);
		tmpName.elt.surf.mouseReleased(stopDrawingCanvas);
	tmpLayer.push(tmpName);tmpName.elt.onmousedown = getLayerName;
	layersList.child(tmpName);
	
	let tmpMini = createImg('','layer'+layers.length);
	tmpMini.position(1,1+tmpStep);tmpMini.size(32,32);
	tmpLayer.push(tmpMini);
	layersList.child(tmpMini);tmpMini.elt.onmousedown = setCurrentLayer;
	
	let tmpSee = createElement('label','h');
	tmpSee.position(50,1+tmpStep);tmpSee.elt.style.backgroundColor = 'white';
	tmpSee.style('padding-left','3px');tmpSee.style('padding-right','3px');
	tmpLayer.push(tmpSee);tmpSee.elt.onmousedown = showLayer;
	layersList.child(tmpSee);

	let tmpAlpha = createElement('label','1.00');
	tmpAlpha.position(75,1+tmpStep);tmpAlpha.elt.style.backgroundColor = 'white';
	tmpAlpha.style('padding-left','2px');tmpAlpha.style('padding-right','2px');
	tmpLayer.push(tmpAlpha);tmpAlpha.elt.onmousedown = getLayerAlpha;
	layersList.child(tmpAlpha);
	
	let tmpUp = createElement('label','<');
	tmpUp.style("transform-origin","0%");tmpUp.style("transform","rotate(90deg)");
	tmpUp.position(120,-8+tmpStep);tmpUp.elt.style.backgroundColor = 'white';
	tmpUp.style('padding-left','2px');tmpUp.style('padding-right','2px');
	tmpLayer.push(tmpUp);tmpUp.mousePressed(reorderLayer);
	layersList.child(tmpUp);
	let tmpDown = createElement('label','>');
	tmpDown.style("transform-origin","0%");tmpDown.style("transform","rotate(90deg)");
	tmpDown.position(120,8+tmpStep);tmpDown.elt.style.backgroundColor = 'white';
	tmpDown.style('padding-left','2px');tmpDown.style('padding-right','2px');
	tmpLayer.push(tmpDown);tmpDown.mousePressed(reorderLayer);
	layersList.child(tmpDown);
	let tmpDel = createElement('label','-');
	tmpDel.position(133,8+tmpStep);tmpDel.elt.style.backgroundColor = 'silver';
	tmpDel.style('padding-left','4px');tmpDel.style('padding-right','3px');
	tmpLayer.push(tmpDel);tmpDel.mousePressed(deleteLayer);
	layersList.child(tmpDel);
	let tmpStyle = createElement('label','style');
	tmpStyle.position(50,41+tmpStep);tmpStyle.elt.style.backgroundColor = 'silver';
	tmpStyle.style('padding-left','2px');tmpStyle.style('padding-right','2px');
	tmpLayer.push(tmpStyle);
	layersList.child(tmpStyle);
	
	let tmpCSS = createElement('label','css');
	tmpCSS.position(90,41+tmpStep);tmpCSS.elt.style.backgroundColor = 'white';
	tmpCSS.style('padding-left','2px');tmpCSS.style('padding-right','2px');
	tmpLayer.push(tmpCSS);tmpCSS.elt.onmousedown = setCSSColor;
	layersList.child(tmpCSS);
	
	layers.push(tmpLayer);
	layersList.elt.style.height = layersList.elt.offsetHeight + 60 + 'px';
}
function minusLayerOn(){
	if(this.elt.style.backgroundColor == 'white'){
		this.elt.style.backgroundColor = 'red';
	}
	else if(this.elt.style.backgroundColor == 'red'){
		this.elt.style.backgroundColor = 'white';
	}
}
function deleteLayer(){
	if(minusLayer.elt.style.backgroundColor == "red"){
		let operId = this.elt.previousSibling.previousSibling.previousSibling.previousSibling.previousSibling.previousSibling.surf.layerId;
		//console.log(operId);
		layers[operId][8].remove();layers[operId][7].remove();layers[operId][6].remove();
		layers[operId][5].remove();layers[operId][4].remove();layers[operId][3].remove();
		layers[operId][2].remove();layers[operId][1].remove();layers[operId][0].elt.surf.elt.remove();
		layers[operId][0].remove();
		delete(layers[operId][8]);delete(layers[operId][7]);delete(layers[operId][6]);
		delete(layers[operId][5]);delete(layers[operId][4]);delete(layers[operId][3]);
		delete(layers[operId][2]);
		
		if(curMini == layers[operId][1].elt){curMini = undefined;curLayer = undefined;}
		delete(layers[operId][1]);
		
		delete(layers[operId][0].elt.surf.elt);delete(layers[operId][0]);
		delete(layers[operId]);
		
		layersList.elt.style.height = layersList.elt.offsetHeight - 60 + 'px';
		if(layers.length >= 1 && operId == 0){
			layers.shift();
			for(let i=0;i<layers.length;i++){
				layers[i][0].elt.surf.layerId = i;
				for(let j=0;j<layers[i].length;j++){
					layers[i][j].elt.style.top = layers[i][j].elt.offsetTop - 60 + 'px';
				}
			}
		}
		else if(layers.length > 1 && operId != 0 && operId != (layers.length-1)){
			layers = layers.slice(0,operId).concat(layers.slice(operId+1,layers.length));
			for(let i=0;i<layers.length;i++){
				layers[i][0].elt.surf.layerId = i;
			}
			for(let i=operId;i<layers.length;i++){console.log(operId);
				for(let j=0;j<layers[i].length;j++){
					layers[i][j].elt.style.top = layers[i][j].elt.offsetTop - 60 + 'px';
				}
			}
		}
		else if(layers.length > 1 && operId == (layers.length-1)){
			layers.pop();//addLayer();
		}
	}
}

function setCurrentLayer(){
	if(curMini != undefined){curMini.style.outline = '0px';}
	curLayer = this.previousSibling.surf;//console.log(this.previousSibling.surf.layerId);
	curMini = this;
	this.style.outline = '2px solid yellow';
}

function showLayer(){
	if(this.style.backgroundColor == 'white'){
		this.style.backgroundColor = 'red';
		this.previousSibling.previousSibling.surf.hide();
	}
	else if(this.style.backgroundColor == 'red'){
		this.style.backgroundColor = 'white';
		this.previousSibling.previousSibling.surf.show();
	}
}

function getLayerName(){
	operParam = this;
	layersInput.elt.type = 'text';layersInput.elt.maxLength = 7;
	layersInput.position(this.offsetLeft,this.offsetTop);
	layersInput.elt.style.zIndex = this.style.zIndex+1;
	layersInput.value(this.textContent);
}

function getLayerAlpha(){
	operLayer = this.previousSibling.previousSibling.previousSibling.surf;
	operParam = this;
	layersInput.elt.type = 'number';layersInput.elt.max = 1.00;layersInput.elt.min = 0.00;
	layersInput.elt.step = 0.01;
	layersInput.position(this.offsetLeft,this.offsetTop);
	layersInput.elt.style.zIndex = this.style.zIndex+1;
	layersInput.value(this.textContent);
}

function hideLayersInput(){
	if(this.type === 'number'){
		operParam.textContent = this.value;
		operLayer.elt.style.opacity = this.value;
	}
	else if(this.type === 'text'){
		operParam.textContent = this.value;
	}
	this.type = 'hidden';this.value = null;
}


function setCSSColor(){
	this.previousSibling.previousSibling.previousSibling.previousSibling.previousSibling
		.previousSibling.previousSibling.previousSibling.surf.style('backgroundColor',color(curColor));
}

function reorderLayer(){
	if(this.elt.textContent == "<"){
		let tmpId = this.elt.previousSibling.previousSibling.previousSibling.previousSibling.surf.layerId;
		let tmpLayer = layers[tmpId];
		if(tmpId > 0){
			for(let i=0;i<layers[tmpId].length;i++){
				layers[tmpId-1][i].elt.style.top = layers[tmpId-1][i].elt.offsetTop + 60 + 'px';
				layers[tmpId][i].elt.style.top = layers[tmpId][i].elt.offsetTop - 60 + 'px';
			}
			layers[tmpId-1][0].elt.surf.layerId = tmpId;
			layers[tmpId][0].elt.surf.layerId = tmpId-1;
			layers[tmpId] = layers[tmpId-1];
			layers[tmpId-1] = tmpLayer;
		}
	}else if(this.elt.textContent == ">"){
		let tmpId = this.elt.previousSibling.previousSibling.previousSibling.previousSibling.previousSibling.surf.layerId;
		let tmpLayer = layers[tmpId];
		if(tmpId < layers.length-1){
			for(let i=0;i<layers[tmpId].length;i++){
				layers[tmpId+1][i].elt.style.top = layers[tmpId+1][i].elt.offsetTop - 60 + 'px';
				layers[tmpId][i].elt.style.top = layers[tmpId][i].elt.offsetTop + 60 + 'px';
			}
			layers[tmpId+1][0].elt.surf.layerId = tmpId;
			layers[tmpId][0].elt.surf.layerId = tmpId+1;
			layers[tmpId] = layers[tmpId+1];
			layers[tmpId+1] = tmpLayer;
		}	
	}
}
