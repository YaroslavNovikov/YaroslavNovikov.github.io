

//				Tools menu functions

function setPenSize(){
	if(penXY.value() == 'CORNER'){
		if(pSize.value() == 10){
			sizeLabel.elt.textContent = '-'.repeat(18)+pSize.value();
		}else if(pSize.value() == 1){
			sizeLabel.elt.textContent = pSize.value()+'-'.repeat(19);
		}else{
			sizeLabel.elt.textContent = '-'.repeat(20/10*pSize.value()-1)+pSize.value()+'-'.repeat(20-(20/10*pSize.value()));
		}
	}
	if(penXY.value() == 'CENTER'){
		if(pSize.value()%2 == 1){
			if(pSize.value() == 9){
				sizeLabel.elt.textContent = '-'.repeat(17)+10+'-';
			}else{
				sizeLabel.elt.textContent = '-'.repeat(20/10*pSize.value()-1)+(ceil(pSize.value()/2)*2)+'-'.repeat(20-(20/10*pSize.value()));
			}
		}
		else{
			if(pSize.value() == 10){
				sizeLabel.elt.textContent = '-'.repeat(18)+pSize.value();
			}else{
				sizeLabel.elt.textContent = '-'.repeat(20/10*pSize.value()-1)+pSize.value()+'-'.repeat(20-(20/10*pSize.value()));
			}
		}
	}
}
function penXYset(){
	if(penXY.value() == 'CORNER'){rectMode(CORNER);}
	else if(penXY.value() == 'CENTER'){rectMode(CENTER);}
	setPenSize();
}
function pen(){
	curLayer.fill(curColor);curLayer.noStroke();
	let penX,penY;
	if(toolsStep_.elt.style.backgroundColor == 'red'){
		penX = floor(mouseX/(stepSize.value()*zoomF))*(stepSize.value()*zoomF);
		penY = floor(mouseY/(stepSize.value()*zoomF))*(stepSize.value()*zoomF);
	}else{
		penX = mouseX;penY = mouseY;
	}
	if(penTypeRadio.value() == 'simple'){
		curLayer.rect(penX,penY,pSize.value()*zoomF,pSize.value()*zoomF);
	}
	else if(penTypeRadio.value() == 'pmouse'){
		if(mouseX != pmouseX || mouseY != pmouseY){
			curLayer.rect(penX,penY,pSize.value()*zoomF,pSize.value()*zoomF);
		}
	}else if(penTypeRadio.value() == 'shot' && penShot == false){	
		curLayer.rect(penX,penY,pSize.value()*zoomF,pSize.value()*zoomF);
		penShot = true;//}
	}
}

function eraser(){
	if(toolsRadio.value() == "Erase"){curLayer.erase();}
	else if(toolsRadio.value() != "Erase"){curLayer.noErase();}
}


function stepTool(){
	if(toolsStep_.elt.style.backgroundColor == 'white'){
		toolsStep_.style('background-color','red');
		
	}else if (toolsStep_.elt.style.backgroundColor == 'red'){
		toolsStep_.style('background-color','white');
	}
}


function fillit(){
	let probe = [];
	let prevColor = color(get(mouseX,mouseY)).levels;
	let ds = width*4;

	loadPixels();

	let st = mouseY*4*width +mouseX*4-4;
	probe.push(st);
	console.log(st);
	for(let i=0;i<1000;i+=1){
		if(pixels[probe[0]+4] == prevColor[0] && pixels[probe[0]+5] == prevColor[1] && pixels[probe[0]+6] == prevColor[2] && pixels[probe[0]+7] == prevColor[3] && (probe[0]+4) % (width*4) != 0){
			pixels[probe[0]+4] = curColor[0];
			pixels[probe[0]+5] = curColor[1];
			pixels[probe[0]+6] = curColor[2];
			pixels[probe[0]+7] = curColor[3];
			probe.push(probe[0]+4);
		}
		if(pixels[probe[0]-4] == prevColor[0] && pixels[probe[0]-3] == prevColor[1] && pixels[probe[0]-2] == prevColor[2] && pixels[probe[0]-1] == prevColor[3] && probe[0] % (width*4) != 0){
			pixels[probe[0]-4] = curColor[0];
			pixels[probe[0]-3] = curColor[1];
			pixels[probe[0]-2] = curColor[2];
			pixels[probe[0]-1] = curColor[3];
			probe.push(probe[0]-4);
		}
		if(pixels[probe[0]+ds] == prevColor[0] && pixels[probe[0]+ds+1] == prevColor[1] && pixels[probe[0]+ds+2] == prevColor[2] && pixels[probe[0]+ds+3] == prevColor[3]){
			pixels[probe[0]+ds] = curColor[0];
			pixels[probe[0]+ds+1] = curColor[1];
			pixels[probe[0]+ds+2] = curColor[2];
			pixels[probe[0]+ds+3] = curColor[3];
			probe.push(probe[0]+ds);
		}				
		if(pixels[probe[0]-ds] == prevColor[0] && pixels[probe[0]-ds+1] == prevColor[1] && pixels[probe[0]-ds+2] == prevColor[2] && pixels[probe[0]-ds+3] == prevColor[3]){
			pixels[probe[0]-ds] = curColor[0];
			pixels[probe[0]-ds+1] = curColor[1];
			pixels[probe[0]-ds+2] = curColor[2];
			pixels[probe[0]-ds+3] = curColor[3];
			probe.push(probe[0]-ds);
		}	
		probe.shift();
		if(probe.length <= 0){break;}
	}

	updatePixels();
}


function repBrush(){
	let probe = [];
	let prevColor = color(get(mouseX,mouseY)).levels;
		//probe.push(mouseX,mouseY);
			//set(mouseX,mouseY,curColor);
	//stroke(curColor);
	//let i = true;
	//point(mouseX,mouseY);
	/*for(;;){
	//while(i){
		if(get(probe[0]+1,probe[1])[0] == tmpColor[0] && probe[0] < width-1){
			point(probe[0]+1,probe[1]);
			probe.push(probe[0]+1,probe[1]);
		}
		if(get(probe[0]-1,probe[1])[0] == tmpColor[0] && probe[0] > 0){
			point(probe[0]-1,probe[1]);
			probe.push(probe[0]-1,probe[1]);
		}
		if(get(probe[0],probe[1]+1)[0] == tmpColor[0] && probe[1] < height-1){
			point(probe[0],probe[1]+1);
			probe.push(probe[0],probe[1]+1);
		}
		if(get(probe[0],probe[1]-1)[0] == tmpColor[0] && probe[1] > 0){
			point(probe[0],probe[1]-1);
			probe.push(probe[0],probe[1]-1);
		}
		//updatePixels();
		probe.shift();probe.shift();
		if(probe.length <= 0){break;}
	}*/
	
	/*	//for(;;){
	while(i){
		if(get(probe[0]+1,probe[1])[0] == tmpColor[0] && probe[0] < width-1){
			point(probe[0]+1,probe[1]);
			probe.push(probe[0]+1,probe[1]);
		}
		if(get(probe[0]-1,probe[1])[0] == tmpColor[0] && probe[0] > 0){
			point(probe[0]-1,probe[1]);
			probe.push(probe[0]-1,probe[1]);
		}
		if(get(probe[0],probe[1]+1)[0] == tmpColor[0] && probe[1] < height-1){
			point(probe[0],probe[1]+1);
			probe.push(probe[0],probe[1]+1);
		}
		if(get(probe[0],probe[1]-1)[0] == tmpColor[0] && probe[1] > 0){
			point(probe[0],probe[1]-1);
			probe.push(probe[0],probe[1]-1);
		}
		//updatePixels();
		probe.shift();probe.shift();
		if(probe.length <= 0){break;}
	}
}
*/
}