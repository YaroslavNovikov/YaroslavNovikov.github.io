let fileBtn,fileMenu;let loadFileBtn, loadFileLabel;let onSurfBtn;let saveBtn;
let canvasBtn,canvasMenu;let zoomLabel;let zoomValue;let zoomValueBr;let zoomF;
let sizeBtn;let sizeX,sizeY,sizeTextX,sizeTextY;let oldW,oldH;let widthBtn,heightBtn,hwBtn;
let seeGrid,gridStep,gridColor;let clearChb, clearYN;let backColor;let checkerLabel,checkerSize;let canvasBorder;
let highLightSurf;//, highLightOn;
let colorBtn,colorMenu;let curColRect, curColPicker;let pipette;let pickingColor = false;let fastRep;let colFromSet;
let tR,tG,tB,tA;let sliderR,sliderG,sliderB,sliderA,curColor;let numR,numG,numB,numA;
let colToSet,pickToSet;let plusColSet,minusColSet,copyColSet,repColSetNum;
let alphaColSetNum,resetColPicker,sliderColSetNum,anumColSetNum,saveColSet,loadColSet,nameColSet;
let toolsBtn,toolsMenu,toolsRadio;let tmpTools = "None";let toolsStep, toolsStep_;
let tSize,pSize,numSize,sizeLabel,penTypeRadio,penXY;let penShot = false;
let replacerBtn,replacerMenu;let fromColor1,rep1red,rep1green,rep1blue,slider1red,slider1green,slider1blue,toColor1;
let multiRepCol;let plusRepCol,minusRepCol,liveColRep,resetColRep,autoColRep,numsColRep;let inputColRep;
let repSlider,replacerDiv,hideRepDiv,pinRepDiv;
let layersBtn,layersMenu,plusLayer,minusLayer,layersSlider,layersList,layersInput;
let optionsBtn,optionsMenu;
let oldMenuXY = [];let masso = [];let unitedDrag = false;let menuBtns = [];let unitedListChb;

//				All menu functions
function showMenu(){
	if(this.menu.elt.hidden == true){
		this.menu.elt.hidden = false;
		if(this == masso[0]){
			unitedListChb.position(this.position().x,this.position().y-this.height);
			unitedListChb.show();
		}
	}
	else if (this.menu.elt.hidden == false){
		this.menu.elt.hidden = true;
		if(this == masso[0]){
			unitedListChb.hide();
		}
	}
}

function dragMenuOn(){
	oldMenuXY = [this.position().x,this.position().y];
	if(this === fileBtn){this.isDrag = true;
		if(this.isUnited == true && this == masso[0]){unitedDrag = true;}
	}
	else if(this === canvasBtn){this.isDrag = true;
		if(this.isUnited == true && this == masso[0]){unitedDrag = true;}
	}
	else if(this === colorBtn){this.isDrag = true;
		if(this.isUnited == true && this == masso[0]){unitedDrag = true;}
	}
	else if(this === toolsBtn){this.isDrag = true;
		if(this.isUnited == true && this == masso[0]){unitedDrag = true;}
	}	
	else if(this === replacerBtn){this.isDrag = true;
		if(this.isUnited == true && this == masso[0]){unitedDrag = true;}
	}
	else if(this === widthBtn || this === heightBtn){this.elt.isDrag = true;}
}
function dragMenuOff(){

	if(this === fileBtn){this.isDrag = false;
		if(oldMenuXY[0] != this.position().x || oldMenuXY[1] != this.position().y){
			this.menu.elt.hidden = !this.menu.elt.hidden;
		//			beginning of union
			if(masso.length == 0){
				for(let i=0;i<menuBtns.length;i++){
					if(dist(this.position().x,this.position().y,menuBtns[i].position().x,menuBtns[i].position().y) < 40 && 
					this.html() != menuBtns[i].html()){
						this.isUnited = true;
						masso.push(menuBtns[i]);masso.push(this);masso[0].isUnited = true;
						this.unitedF[0] = masso[0].width/1;
					}
				}
			}//		or continue of union
			else if(masso.length != 0 && dist(this.position().x,this.position().y,masso[0].position().x,masso[0].position().y) < 40 &&
					this.isUnited == false){
				this.isUnited = true;
				this.unitedF[0] = masso[masso.length-1].unitedF[0] + masso[masso.length-1].width/1;
				masso.push(this);
			}	
		}
	}
	else if(this === canvasBtn){this.isDrag = false;
		if(oldMenuXY[0] != this.position().x || oldMenuXY[1] != this.position().y){
			this.menu.elt.hidden = !this.menu.elt.hidden;
		//			beginning of union
			if(masso.length == 0){
				for(let i=0;i<menuBtns.length;i++){
					if(dist(this.position().x,this.position().y,menuBtns[i].position().x,menuBtns[i].position().y) < 40 && 
					this.html() != menuBtns[i].html()){
						this.isUnited = true;
						masso.push(menuBtns[i]);masso.push(this);masso[0].isUnited = true;
						this.unitedF[0] = masso[0].width/1;
					}
				}
			}//		or continue of union
			else if(masso.length != 0 && dist(this.position().x,this.position().y,masso[0].position().x,masso[0].position().y) < 40 &&
					this.isUnited == false){
				this.isUnited = true;
				this.unitedF[0] = masso[masso.length-1].unitedF[0] + masso[masso.length-1].width/1;
				masso.push(this);
			}
		}
	}
	else if(this === colorBtn){this.isDrag = false;
		if(oldMenuXY[0] != this.position().x || oldMenuXY[1] != this.position().y){
			this.menu.elt.hidden = !this.menu.elt.hidden;
		//			beginning of union
			if(masso.length == 0){
				for(let i=0;i<menuBtns.length;i++){
					if(dist(this.position().x,this.position().y,menuBtns[i].position().x,menuBtns[i].position().y) < 40 && 
					this.html() != menuBtns[i].html()){
						this.isUnited = true;
						masso.push(menuBtns[i]);masso.push(this);masso[0].isUnited = true;
						this.unitedF[0] = masso[0].width/1;
					}
				}//		or continue of union
			}else if(masso.length != 0 && dist(this.position().x,this.position().y,masso[0].position().x,masso[0].position().y) < 40 &&
						this.isUnited == false){
					this.isUnited = true;
					this.unitedF[0] = masso[masso.length-1].unitedF[0] + masso[masso.length-1].width/1;
					masso.push(this);
			}
		}
	}
	else if(this === toolsBtn){this.isDrag = false;
		if(oldMenuXY[0] != this.position().x || oldMenuXY[1] != this.position().y){
			this.menu.elt.hidden = !this.menu.elt.hidden;
		//			beginning of union
			if(masso.length == 0){
				for(let i=0;i<menuBtns.length;i++){
					if(dist(this.position().x,this.position().y,menuBtns[i].position().x,menuBtns[i].position().y) < 40 && 
					this.html() != menuBtns[i].html()){
						this.isUnited = true;
						masso.push(menuBtns[i]);masso.push(this);masso[0].isUnited = true;
						this.unitedF[0] = masso[0].width/1;
					}
				}
			}//		or continue of union
			else if(masso.length != 0 && dist(this.position().x,this.position().y,masso[0].position().x,masso[0].position().y) < 40 &&
					this.isUnited == false){
				this.isUnited = true;
				this.unitedF[0] = masso[masso.length-1].unitedF[0] + masso[masso.length-1].width/1;
				masso.push(this);
			}
		}
	}
	else if(this === replacerBtn){this.isDrag = false;
		if(oldMenuXY[0] != this.position().x || oldMenuXY[1] != this.position().y){
			this.menu.elt.hidden = !this.menu.elt.hidden;
			replacerDiv.elt.zH = replacerDiv.elt.offsetTop;
		//			beginning of union
			if(masso.length == 0){
				for(let i=0;i<menuBtns.length;i++){
					if(dist(this.position().x,this.position().y,menuBtns[i].position().x,menuBtns[i].position().y) < 40 && 
					this.html() != menuBtns[i].html()){
						this.isUnited = true;
						masso.push(menuBtns[i]);masso.push(this);masso[0].isUnited = true;
						this.unitedF[0] = masso[0].width/1;
					}
				}
			}//		or continue of union
			else if(masso.length != 0 && dist(this.position().x,this.position().y,masso[0].position().x,masso[0].position().y) < 40 &&
					this.isUnited == false){
				this.isUnited = true;
				this.unitedF[0] = masso[masso.length-1].unitedF[0] + masso[masso.length-1].width/1;
				masso.push(this);
			}
		}
	}
	else if(this === widthBtn){this.elt.isDrag = false;
		for(let i=0;i<layers.length;i++){
			layers[i][0].elt.surf.loadPixels();
			layers[i][0].elt.surf.resizeCanvas(widthBtn.position().x-8,height);
			layers[i][0].elt.surf.updatePixels();
		}
	}
	else if(this === heightBtn){this.elt.isDrag = false;
		for(let i=0;i<layers.length;i++){
			layers[i][0].elt.surf.loadPixels();
			layers[i][0].elt.surf.resizeCanvas(width,heightBtn.position().y-2);
			layers[i][0].elt.surf.updatePixels();
		}
	}
}

function menusToList(){
	for(let i=1;i<masso.length;i++){
		if(unitedListChb.checked()){
			masso[i].unitedF[1] = masso[i-1].unitedF[1] + masso[i-1].menu.size().height;
			masso[i].menu.position(masso[i].menu.position().x,masso[i].menu.position().y+masso[i].unitedF[1]);
		}else{	
			masso[i].menu.position(masso[i].menu.position().x,masso[i].menu.position().y-masso[i].unitedF[1]);
			masso[i].unitedF[1] = 0;
		}
	}
}


