let colorSet = [];let dtX,dtY;let toId;let tmpColSetCell,tmpColSetCol;//let tmpColSet;
let curColTool = undefined;

//				Color menu functions
function changeColor(){

	if(this === curColPicker){
		sliderR.value(unhex(curColPicker.value().slice(1,3)));
		sliderG.value(unhex(curColPicker.value().slice(3,5)));
		sliderB.value(unhex(curColPicker.value().slice(5,7)));
		numR.value(unhex(curColPicker.value().slice(1,3)));
		numG.value(unhex(curColPicker.value().slice(3,5)));
		numB.value(unhex(curColPicker.value().slice(5,7)));
	}
	else if(this === sliderR){
		numR.value(sliderR.value());
	}
	else if(this === sliderG){
		numG.value(sliderG.value());
	}
	else if(this === sliderB){
		numB.value(sliderB.value());
	}
	else if(this === sliderA){
		numA.value(sliderA.value());
	}
	else if(this === numR){
		sliderR.value(numR.value());
	}
	else if(this === numG){
		sliderG.value(numG.value());
	}
	else if(this === numB){
		sliderB.value(numB.value());
	}
	else if(this === numA){
		sliderA.value(numA.value());
	}
	curColPicker.value("#"+hex(sliderR.value(),2)+hex(sliderG.value(),2)+hex(sliderB.value(),2));
	curColor = [sliderR.value(),sliderG.value(),sliderB.value(),sliderA.value()];
	curColRect.style("background-image", "linear-gradient(to right,"+
		color(curColor[0],curColor[1],curColor[2])+" 50%,"+ color(curColor)+" 50%)");
	
}
//				Color tools/icons functions
function pickColor(){
	if(curColTool != this){
		if(curColTool != undefined){curColTool.removeClass('icon_Light')};
		curColTool = this;
		this.addClass('icon_Light');
		tmpTool = toolsRadio.value();
		toolsRadio.value("None");
		cursor('curs/picker.png',-pipette.size().width,pipette.size().height);
		pickToSet.show();
	}
	else{
		curColTool = undefined;
		pipette.removeClass('icon_Light');
		toolsRadio.value(tmpTool);
		cursor("initial");
		pickToSet.hide();
	}
}
function fastReplaceColorOn(){
	if(curColTool != this){
		if(curColTool != undefined){curColTool.removeClass('icon_Light')};
		curColTool = this;
		tmpTool = toolsRadio.value();
		toolsRadio.value('None');
		this.addClass('icon_Light');
		cursor('curs/repcolcur.png',-pipette.size().width,pipette.size().height);
		pickToSet.hide();
	}
	else{
		curColTool = undefined;
		this.removeClass('icon_Light');
		toolsRadio.value(tmpTool);
		cursor("initial");
	}
}
function fastReplaceColor(){
	let tmpColor = curLayer.get(mouseX,mouseY);
		curLayer.loadPixels();
		for(let i=0;i<width*4*height;i+=4){
			if(curLayer.pixels[i]==tmpColor[0] && curLayer.pixels[i+1]==tmpColor[1] && curLayer.pixels[i+2]==tmpColor[2] && curLayer.pixels[i+3]==tmpColor[3]){
				curLayer.pixels[i] = curColor[0];
				curLayer.pixels[i+1] = curColor[1];
				curLayer.pixels[i+2] = curColor[2];
				curLayer.pixels[i+3] = curColor[3];
			}
		}
		curLayer.updatePixels();
}

function pickingToSetOn(){
	if(curColTool != this){
		if(curColTool != undefined){curColTool.removeClass('icon_Light');}
		curColTool = this;
		this.addClass('icon_Light');
		cursor('curs/picker2.png',-pipette.size().width,pipette.size().height);
	}else{
		curColTool = undefined;
		this.removeClass('icon_Light');this.hide();
		toolsRadio.value(tmpTool);
		cursor("initial");
	}
}

function addColSet(){
	let tmpColSet = [];
	tmpColSet[0] = createElement('label','');tmpColSet[0].size(200,70);
	tmpColSet[0].position(colorMenu.position().x,colorMenu.position().y+colorMenu.height);//+(70*colorSet.length));
	tmpColSet[0].style('background-color','rgba('+random(255)+',10,0,0.5)');
	tmpColSet[0].mousePressed(getDeltaXY);tmpColSet[0].mouseMoved(moveColSet);
	tmpColSet[0].mouseClicked(selectColSet);
	//tmpColSet[0].moving = false;
	for(let i =1;i<13;i++){
		tmpColSet[i] = createElement('label','');tmpColSet[i].size(24,24);
		tmpColSet[i].elt.style.backgroundColor = 'white';tmpColSet[i].elt.style.borderWidth = '0px';
		if(i<7){
			tmpColSet[i].position(5+((i-1)*30),5);
			//tmpColSet[i].position(tmpColSet[0].elt.offsetLeft+5+((i-1)*30),tmpColSet[0].elt.offsetTop+5);
		}else{
			tmpColSet[i].position(5+((i-7)*30),35);
			//tmpColSet[i].position(tmpColSet[0].elt.offsetLeft+5+((i-7)*30),tmpColSet[0].elt.offsetTop+35);
		}
		tmpColSet[0].child(tmpColSet[i]);tmpColSet[i].mousePressed(getColorFromSet);
	}
	tmpColSet.plus = createElement('label','+');tmpColSet.plus.style('background-color','white');
	tmpColSet.plus.style('padding-left','2px');tmpColSet.plus.style('padding-right','2px');
	tmpColSet.plus.position(184,10);tmpColSet[0].child(tmpColSet.plus);
	tmpColSet.plus.mousePressed(addColSetNum);
	tmpColSet.minus = createElement('label','-');tmpColSet.minus.style('background-color','white');
	tmpColSet.minus.style('padding-left','3px');tmpColSet.minus.style('padding-right','4px');
	tmpColSet.minus.position(184,37);tmpColSet[0].child(tmpColSet.minus);
	tmpColSet.minus.mousePressed(delColSetNum);
	tmpColSet[0].elt.style.zIndex = colorMenu.elt.style.zIndex;
	colorSet.push(tmpColSet);tmpColSet[0].elt.idColSet = colorSet.length-1;
	tmpColSet[1].html(tmpColSet[0].elt.idColSet);tmpColSet[1].style('textIndent','4px');
}
function addColSetNum(){
	let ndex = this.elt.parentElement.idColSet;
	let tmpColNum = createElement('label','');
	tmpColNum.size(24,24);tmpColNum.elt.style.backgroundColor = 'white';
	tmpColNum.elt.style.borderWidth = '0px';tmpColNum.mousePressed(getColorFromSet);
	let tmpLen = colorSet[ndex].length-1;
	tmpColNum.position(5+(tmpLen%6*30),5+(30*floor(tmpLen/6)));
	colorSet[ndex].push(tmpColNum);colorSet[ndex][0].child(tmpColNum);
	let colSetStep = ceil((colorSet[ndex].length-1)/6) - ceil(tmpLen/6);
	if(colSetStep == 1){
		colorSet[ndex][0].elt.style.height = colorSet[ndex][0].size().height+30+'px';//*floor(colorSet[ndex]));
	}
	if(tmpColNum == colorSet[ndex][1]){
		tmpColNum.html(colorSet[ndex][0].elt.idColSet);tmpColNum.style('textIndent','4px');
	}
}
function delColSetNum(){
if(minusColSet.elt.style.backgroundColor == 'white'){
	let ndex = this.elt.parentElement.idColSet;
	let tmpLen = colorSet[ndex].length-1;
	if(colorSet[ndex].length > 1){
		colorSet[ndex][colorSet[ndex].length-1].remove();
		delete(colorSet[ndex].pop());
		let colSetStep = ceil((colorSet[ndex].length-1)/6) - ceil(tmpLen/6);
		if(colSetStep == -1 && colorSet[ndex][0].size().height >= 70){
			colorSet[ndex][0].elt.style.height = colorSet[ndex][0].size().height-30+'px';
		}
	}
	else if(colorSet[ndex].length <= 1){
		colorSet[ndex].plus.remove();delete(colorSet[ndex].plus);
		colorSet[ndex].minus.remove();delete(colorSet[ndex].minus);
		colorSet[ndex][0].remove();delete(colorSet[ndex][0]);
		delete(colorSet[ndex]);
		if(ndex == 0){
			colorSet.shift();
			for(let i=0;i<colorSet.length;i++){
				colorSet[i][0].elt.idColSet = i;
				colorSet[i][1].html(i);
			}
		}
		else if(ndex > 0 && ndex < colorSet.length-1){
			colorSet = colorSet.slice(0,ndex).concat(colorSet.slice(ndex+1,colorSet.length));
			for(let i =0;i<colorSet.length;i++){
				colorSet[i][0].elt.idColSet = i;
				colorSet[i][1].html(i);
			}
		}
		else if(ndex == colorSet.length-1){
			colorSet.pop();
		}
		toId = undefined;
	}
}
else if(minusColSet.elt.style.backgroundColor == 'red'){
	let ndex = this.elt.parentElement.idColSet;
	for(let i=colorSet[ndex].length-1;i>0;i--){
		colorSet[ndex][i].remove();delete(colorSet[ndex][i]);
	}
	colorSet[ndex].plus.remove();delete(colorSet[ndex].plus);
	colorSet[ndex].minus.remove();delete(colorSet[ndex].minus);
	colorSet[ndex][0].remove();delete(colorSet[ndex][0]);
	delete(colorSet[ndex]);
		if(ndex == 0){
			colorSet.shift();
			for(let i=0;i<colorSet.length;i++){
				colorSet[i][0].elt.idColSet = i;
				colorSet[i][1].html(i);
			}
		}
		else if(ndex > 0 && ndex < colorSet.length-1){
			colorSet = colorSet.slice(0,ndex).concat(colorSet.slice(ndex+1,colorSet.length));
			for(let i =0;i<colorSet.length;i++){
				colorSet[i][0].elt.idColSet = i;
				colorSet[i][1].html(i);
			}
		}
		else if(ndex == colorSet.length-1){
			colorSet.pop();
		}
		toId = undefined;
}
}


function getDeltaXY(){
	dtX = mouseX-this.position().x;
	dtY = mouseY-this.position().y;
}
function moveColSet(){
	if(mouseIsPressed){
		this.position(mouseX-dtX,mouseY-dtY);
	}
}
function selectColSet(){
	if(toId == undefined){toId = this.elt.idColSet;this.style('outline','2px solid yellow');}
	console.log(toId);
	if(toId != this.elt.idColSet){
		colorSet[toId][0].style('outlineWidth','0px');
		toId = this.elt.idColSet;
		this.style('outline','2px solid yellow');
	}
}

function colorToSet(){
	if(toId != undefined){
	for(let i=1;i<colorSet[toId].length;i++){
		if(colorSet[toId][i].elt.style.borderWidth == '0px'){
			colorSet[toId][i].elt.style.backgroundColor = color(curColor);
			colorSet[toId][i].elt.style.borderWidth = '1px';
			break;
		}
	}
	}
}

function colorFromSetOn(){
	if(!this.hasClass('icon_Light')){
		this.addClass('icon_Light');
	}
	else if(this.hasClass('icon_Light')){
		this.removeClass('icon_Light');
	}
}

function getColorFromSet(){
	if(colFromSet.hasClass('icon_Light')){
		curColor = color(this.elt.style.backgroundColor).levels;
		sliderR.value(curColor[0]);numR.value(curColor[0]);
		sliderG.value(curColor[1]);numG.value(curColor[1]);
		sliderB.value(curColor[2]);numB.value(curColor[2]);
		sliderA.value(curColor[3]);numA.value(curColor[3]);
		curColPicker.value("#"+hex(curColor[0],2)+hex(curColor[1],2)+hex(curColor[2],2));
		curColRect.style("background-image", "linear-gradient(to right,"+
			color(curColor[0],curColor[1],curColor[2])+" 50%,"+ color(curColor)+" 50%)");
	}
	else if(alphaColSetNum.elt.style.backgroundColor != 'red' && resetColPicker.elt.style.backgroundColor == 'red'){
		let tmpCol = curColPicker.value();
		let thisCol = color(this.elt.style.backgroundColor).levels;
		curColPicker.value("#"+hex(thisCol[0],2)+hex(thisCol[1],2)+hex(thisCol[2],2));
		let tmpThis = this;
		function changeColSetNum(){
			let tmpRGB = color(curColPicker.value()).levels;
			tmpThis.elt.style.backgroundColor = color([tmpRGB[0],tmpRGB[1],tmpRGB[2],thisCol[3]]);
			curColPicker.value(tmpCol);
			tmpThis.elt.style.borderWidth = '1px';
			tmpThis.removeAttribute('for');
		}
		curColPicker.changed(changeColSetNum);
		this.attribute('for','curColPicker');
	}
	else if(alphaColSetNum.elt.style.backgroundColor == 'red'){
		this.removeAttribute('for');
		tmpColSetCol = color(this.elt.style.backgroundColor).levels;
		sliderColSetNum.value(tmpColSetCol[3]);
		anumColSetNum.value(tmpColSetCol[3]);
		tmpColSetCell = this;
	}
	else if(repColSetNum.elt.style.backgroundColor == 'red'){
		this.elt.style.backgroundColor = color(curColor);
		this.elt.style.borderWidth = '1px';
	}
}
function resetColorPicker(){
	if(resetColPicker.elt.style.backgroundColor == 'red'){
		curColPicker.changed(changeColor);
		resetColPicker.style('background-color','white');resetColPicker.html('color picker');
	}else if(resetColPicker.elt.style.backgroundColor == 'white'){
		resetColPicker.style('background-color','red');resetColPicker.html('reset color picker');
	}
}

function turnColSetNumA(){
	if(this.elt.style.backgroundColor == 'red'){
		//curColPicker.changed(changeColor);
		this.style('background-color','white');//resetColPicker.html('color picker');
	}else if(this.elt.style.backgroundColor == 'white'){
		this.style('background-color','red');//resetColPicker.html('reset color picker');
		tmpColSetCell = undefined;tmpColSetColl = undefined;
	}
}
function changeColSetNumA(){
if(alphaColSetNum.elt.style.backgroundColor == 'red'){
	if(this === sliderColSetNum){
		anumColSetNum.value(this.value());
	}else if(this === anumColSetNum){
		sliderColSetNum.value(this.value());
	}
	tmpColSetCell.elt.style.borderWidth = '1px';
	tmpColSetCell.elt.style.backgroundColor = color([tmpColSetCol[0],tmpColSetCol[1],tmpColSetCol[2],Number(this.value())]);
}
}

function copyColorSet(){
if(toId != undefined){
	addColSet();
	let srcLen = colorSet[toId].length;let dstLen = colorSet[colorSet.length-1].length;
	colorSet[colorSet.length-1][0].elt.style.backgroundColor = 'aqua';
	let ndex = this.elt.parentElement.idColSet;
	if(dstLen < srcLen){
		for(let i = 0;i<srcLen-dstLen;i++){
			let tmpColNum = createElement('label','');
			tmpColNum.size(24,24);tmpColNum.elt.style.backgroundColor = 'white';
			tmpColNum.elt.style.borderWidth = '0px';
			let tmpLen = colorSet[colorSet.length-1].length-1;
			tmpColNum.position(5+(tmpLen%6*30),5+(30*floor(tmpLen/6)));
			colorSet[colorSet.length-1].push(tmpColNum);colorSet[colorSet.length-1][0].child(tmpColNum);
			let colSetStep = ceil((colorSet[colorSet.length-1].length-1)/6) - ceil(tmpLen/6);
			if(colSetStep == 1){
				colorSet[colorSet.length-1][0].elt.style.height = colorSet[colorSet.length-1][0].size().height+30+'px';
			}
		}
	}	
	for(let i = 1;i<colorSet[toId].length;i++){
		colorSet[colorSet.length-1][i].elt.style.backgroundColor = colorSet[toId][i].elt.style.backgroundColor;
		colorSet[colorSet.length-1][i].elt.style.borderWidth = colorSet[toId][i].elt.style.borderWidth;
	}
}}