	
function inits(){
	pixelDensity(displayDensity());
//					Canvas initialization
	surf = createCanvas(100,100);frameRate(0);
	surf.style("background-image","url(backCell.png)");
	surf.style("background-repeat","repeat");
	textSize(5);
	noSmooth();setAttributes('antialias', false);
	widthBtn = createButton('<>');widthBtn.elt.isDrag = false;
	widthBtn.position(surf.width+surf.position().x,surf.height/2);
	widthBtn.style("transform-origin","0%");
	widthBtn.mousePressed(dragMenuOn);widthBtn.mouseReleased(dragMenuOff);
	heightBtn = createButton('<>');heightBtn.elt.isDrag = false;
	heightBtn.position(surf.width/2+surf.position().x,surf.height-2);
	heightBtn.style("transform-origin","0%");
	heightBtn.style("transform","rotate(90deg)");
	heightBtn.mousePressed(dragMenuOn);heightBtn.mouseReleased(dragMenuOff);

//				FILE TAB
	fileBtn = createButton("File");
	fileBtn.position(surf.position().x+surf.width,surf.position().y);
	fileMenu = createDiv("");fileMenu.size(180);
	fileMenu.style("background-color",'silver');
	fileMenu.position(fileBtn.position().x,fileBtn.position().y+fileBtn.height);
	loadFileBtn = createFileInput(loadFile);loadFileBtn.id('loadFileBtn');
	loadFileBtn.size(180);
	fileMenu.child(loadFileBtn);
	loadFileLabel = createElement('label','Load file');loadFileLabel.elt.setAttribute('for','loadFileBtn');
	loadFileLabel.position(loadFileBtn.position().x,loadFileBtn.position().y);
	loadFileLabel.style('background-color','white');loadFileLabel.style('margin','1px');
	loadFileLabel.style('padding-left','8px');loadFileLabel.style('padding-top','1px');loadFileLabel.style('padding-right','20px');
	fileMenu.child(loadFileLabel);
	onSurfBtn = createButton("On layer");fileMenu.child(onSurfBtn);
	fileMenu.child(createElement('br'));
	saveBtn = createButton("Save");fileMenu.child(saveBtn);
	fileBtn.mouseClicked(showMenu);
	fileBtn.mousePressed(dragMenuOn);
	fileBtn.mouseReleased(dragMenuOff);
	onSurfBtn.mouseClicked(drawLoaded);
	saveBtn.mouseClicked(saveCanvasToFile);
	fileBtn.isDrag = false;
	fileBtn.unitedF = [0,0];
	fileBtn.isUnited = false;
	fileBtn.menu = fileMenu;

//				CANVAS TAB
	canvasBtn = createButton("Canvas");
	canvasBtn.position(200,surf.position().y);
	canvasMenu = createDiv("");
	canvasMenu.size(210,130);
	canvasMenu.position(canvasBtn.position().x,canvasBtn.position().y+canvasBtn.height);
	canvasMenu.style('background-color','yellow');
	zoomLabel = createElement('label',"Zoom");zoomLabel.style('padding-left','2px');
	canvasMenu.child(zoomLabel);
	zoomValue = createSelect();
	canvasMenu.child(zoomValue);zoomValue.style('marginLeft','2px');
	zoomValue.option('100%');zoomValue.option('200%');zoomValue.option('300%');zoomValue.option('400%');zoomValue.option('500%');
	zoomValue.option('600%');zoomValue.option('700%');zoomValue.option('800%');zoomValue.option('900%');zoomValue.option('1000%');
	zoomValue.option('1100%');zoomValue.option('1200%');zoomValue.option('1300%');zoomValue.option('1400%');zoomValue.option('1500%');
	zoomValue.option('1600%');zoomValue.option('1700%');zoomValue.option('1800%');zoomValue.option('1900%');zoomValue.option('2000%');
	zoomValueBr = createElement('br');
	canvasMenu.child(zoomValueBr);
	sizeBtn = createButton("Size");sizeBtn.size(57);
	canvasMenu.child(sizeBtn);
	sizeTextX = createElement('label','x:');sizeTextX.style('padding','5px');
	canvasMenu.child(sizeTextX);
	sizeX = createInput('','number');sizeX.size(49);sizeX.elt.max = 10000;sizeX.elt.min = 1;
	canvasMenu.child(sizeX);
	sizeX.value(width);sizeX.input(sizeBtnText);oldW = sizeX.value();
	sizeTextY = createElement('label','y:');sizeTextY.style('padding','5px');
	canvasMenu.child(sizeTextY);
	sizeY = createInput('','number');sizeY.size(49);sizeY.elt.max = 10000;sizeY.elt.min = 1;
	canvasMenu.child(sizeY);
	sizeY.value(height);sizeY.input(sizeBtnText);oldH = sizeY.value();
	seeGrid = createCheckbox("Grid",true);seeGrid.size(sizeBtn.width);
	canvasMenu.child(seeGrid);
	seeGrid.changed(showGrid);
	gridStep = createInput('','number');gridStep.size(50);gridStep.elt.max = 64;gridStep.elt.min = 1;
	gridStep.elt.defaultValue = 10;
	gridStep.position(seeGrid.position().x+seeGrid.width,seeGrid.position().y);
	canvasMenu.child(gridStep);
	gridColor = createElement('label','');gridColor.elt.style.backgroundColor = 'black';
	gridColor.mouseClicked(recolorGrid);
	canvasMenu.child(gridColor);gridColor.size(42,19);gridColor.style('border','1px solid black');
	gridColor.position(gridStep.position().x+gridStep.width,gridStep.position().y);
	zoomF = (int(zoomValue.value())/100);
	zoomValue.changed(zoomFactor);
	clearChb = createCheckbox('Clear:',false);
	clearChb.position(zoomValue.position().x+zoomValue.size().width,zoomValue.position().y);
	canvasMenu.child(clearChb);
	clearYN = createElement('label','No');
	clearYN.position(clearChb.position().x+clearChb.size().width+2,clearChb.position().y+2);
	canvasMenu.child(clearYN);
	clearChb.changed(prepareClear);
	clearYN.mouseClicked(clearSurface);
	backColor = createElement('label',"CSS back");backColor.size(64,32);
	backColor.elt.style.wordSpacing = '2px';
	backColor.style("background-image","linear-gradient(to right,yellow 55%,rgba(0,0,0,0) 55%), url('backCell.png')");
	backColor.style('padding','3px');backColor.style('background-clip','content-box');
	backColor.position(seeGrid.position().x+2,seeGrid.position().y+seeGrid.size().height+2);
	canvasMenu.child(backColor);
	backColor.mouseClicked(setBackgroundColor);	
	checkerLabel = createElement('label','Checker size:');//checkerLabel.size(60);
	checkerLabel.position(backColor.position().x+backColor.size().width,backColor.position().y);
	canvasMenu.child(checkerLabel);
	checkerSize = createInput('20','number');checkerSize.size(45);checkerSize.elt.max = 64;checkerSize.elt.min = 0;
	checkerSize.position(checkerLabel.position().x+checkerLabel.size().width,checkerLabel.position().y);
	canvasMenu.child(checkerSize);
	checkerLabel.mouseClicked(resetChecker);
	checkerSize.input(resizeChecker);
	canvasBorder = createElement('label','Border off');
	canvasBorder.position(checkerLabel.position().x,checkerLabel.position().y + checkerLabel.height);
	canvasBorder.elt.style.backgroundColor = "transparent";
	canvasMenu.child(canvasBorder);
	canvasBorder.mouseClicked(turnBorder);
	hwBtn = createElement("label",'HW');//hwBtn.position(backColor.position().x,104);
	hwBtn.position(gridColor.position().x + gridColor.elt.width + 15,gridColor.position().y+2);
	hwBtn.style('background-color','orange');hwBtn.mousePressed(hwBtnTurn);
	canvasMenu.child(hwBtn);

	canvasBtn.mouseClicked(showMenu);
	sizeBtn.mouseClicked(sizeBtnResize);
	sizeTextX.mouseClicked(sizeBtnResize);
	sizeTextY.mouseClicked(sizeBtnResize);
	canvasBtn.mousePressed(dragMenuOn);
	canvasBtn.mouseReleased(dragMenuOff);
	canvasBtn.isDrag = false;
	canvasBtn.unitedF = [0,0];
	canvasBtn.isUnited = false;
	canvasBtn.menu = canvasMenu;

//			COLOR TAB
	colorBtn = createButton("Color");
	colorBtn.position(320,surf.position().y);
	colorBtn.mouseClicked(showMenu);
	colorMenu = createDiv("");colorMenu.style('background-color','pink');
	colorMenu.size(200,330);
	colorMenu.position(colorBtn.position().x,colorBtn.position().y+colorBtn.height);
	tR = createElement('label',"R");tR.style('background-color','white').elt.style.padding = "2px";
	colorMenu.child(tR);tR.size(12);
	tR.position(0,0);
	sliderR = createSlider(0,255,50);sliderR.position(tR.position().x+16,0);
	colorMenu.child(sliderR);
	numR = createInput(String(sliderR.value()),'number');numR.size(40);
	numR.position(sliderR.position().x + sliderR.width+2,sliderR.position().y);
	numR.elt.max = 255;numR.elt.min = 0;
	colorMenu.child(numR);
	tG = createElement('label',"G");tG.style('background-color','white').elt.style.padding = "2px";
	tG.position(0,30);
	colorMenu.child(tG);
	sliderG = createSlider(0,255,50);sliderG.position(tG.position().x+16,tG.position().y);
	colorMenu.child(sliderG);
	numG = createInput(String(sliderG.value()),'number');numG.size(40);
	numG.position(sliderG.position().x + sliderG.width+2,sliderG.position().y);
	numG.elt.max = 255;numG.elt.min = 0;
	colorMenu.child(numG);
	tB = createElement('label',"B");tB.style('background-color','white').elt.style.padding = "2px";
	tB.size(12);tB.position(0,60);
	colorMenu.child(tB);
	sliderB = createSlider(0,255,50);
	sliderB.position(tB.position().x+16,tB.position().y);
	colorMenu.child(sliderB);
	numB = createInput(String(sliderB.value()),'number');numB.size(40);
	numB.position(sliderB.position().x + sliderB.width+2,sliderB.position().y);
	numB.elt.max = 255;numB.elt.min = 0;
	colorMenu.child(numB);
	tA = createElement('label',"A");tA.style('background-color','white').elt.style.padding = "2px";
	tA.position(sliderB.position().x+sliderB.width-25,sliderB.position().y+sliderB.height);
	colorMenu.child(tA);
	sliderA = createSlider(0,255,50);
	sliderA.position(tA.position().x+6,tA.position().y+15);
	sliderA.style("transform-origin","0%");
	sliderA.style("transform","rotate(90deg)");
	colorMenu.child(sliderA);
	numA = createInput(String(sliderA.value()),'number');numA.size(40);
	numA.position(sliderA.position().x-numA.width/2,sliderA.position().y+sliderA.width+10);
	numA.elt.max = 255;numA.elt.min = 0;
	colorMenu.child(numA);
	curColRect= createElement('label','');
	curColRect.elt.style.width = "100px";
	curColRect.elt.style.height = "100px";
	curColRect.position(tB.position().x+15,tB.position().y+sliderB.height+5);
	colorMenu.child(curColRect);
	pipette = createImg('icos/pipette.png',"Pipette");
	pipette.position(numB.position().x,tA.position().y);
	colorMenu.child(pipette);
	curColor = [sliderR.value(),sliderG.value(),sliderB.value(),sliderA.value()];
	curColRect.style("background-image", "linear-gradient(to right,"+
		color(curColor[0],curColor[1],curColor[2])+" 50%,"+ color(curColor)+" 50%)");
	curColPicker = createColorPicker();curColPicker.id('curColPicker');curColPicker.hide();
	colorMenu.child(curColPicker);
	curColRect.elt.setAttribute('for','curColPicker');
	curColPicker.changed(changeColor);
	fastRep = createImg('icos/repcolico.png','Fastrepl');
	fastRep.position(pipette.position().x, pipette.position().y+42);
	colorMenu.child(fastRep);
	fastRep.elt.choosen = false;
	fastRep.mouseClicked(fastReplaceColorOn);
	colToSet = createImg('icos/coltoset.png','coltoset');
	colToSet.position(pipette.position().x,fastRep.position().y+42);
	colorMenu.child(colToSet);
	pickToSet = createImg('icos/picktoset.png','coltoset');
	pickToSet.position(pipette.position().x,colToSet.position().y);
	colorMenu.child(pickToSet);pickToSet.hide();pickToSet.mousePressed(pickingToSetOn);
	colToSet.mousePressed(colorToSet);
	
	colFromSet = createImg('icos/colfromset.png','colfromset');
	colFromSet.position(pipette.position().x,colToSet.position().y+36);
	colorMenu.child(colFromSet);
	colFromSet.mousePressed(colorFromSetOn);

	plusColSet = createElement('label','[+]');plusColSet.style('background-color','white');
	plusColSet.position(155,numA.position().y);plusColSet.style('padding-bottom','2px');
	colorMenu.child(plusColSet);plusColSet.mousePressed(addColSet);
	minusColSet = createElement('label','[-]');minusColSet.style('background-color','white');
	minusColSet.position(178,numA.position().y);minusColSet.style('padding-bottom','2px');
	colorMenu.child(minusColSet);minusColSet.mousePressed(turnResetAutoLive);
	copyColSet = createElement('label','copy');copyColSet.style('background-color','white');
	copyColSet.style('padding-left','1px');copyColSet.style('padding-right','1px');
	copyColSet.position(plusColSet.position().x+5,plusColSet.position().y+plusColSet.height+6);
	colorMenu.child(copyColSet);copyColSet.mousePressed(copyColorSet);
	repColSetNum = createElement('label','replace');repColSetNum.style('background-color','white');
	repColSetNum.style('padding-left','1px');repColSetNum.style('padding-right','1px');
	repColSetNum.position(copyColSet.position().x-55,copyColSet.position().y);
	colorMenu.child(repColSetNum);repColSetNum.mousePressed(turnResetAutoLive);
	alphaColSetNum = createElement('label','alpha');alphaColSetNum.style('background-color','white');
	alphaColSetNum.style('padding-left','1px');alphaColSetNum.style('padding-right','1px');
	alphaColSetNum.position(copyColSet.position().x,copyColSet.position().y+(copyColSet.height*2)+10);
	colorMenu.child(alphaColSetNum);alphaColSetNum.mousePressed(turnColSetNumA);
	resetColPicker = createElement('label','color picker');resetColPicker.style('background-color','white');
	resetColPicker.style('padding-left','1px');resetColPicker.style('padding-right','2px');
	resetColPicker.position(repColSetNum.position().x-80,repColSetNum.position().y+repColSetNum.height+4);
	colorMenu.child(resetColPicker);resetColPicker.mousePressed(resetColorPicker);
	sliderColSetNum = createSlider(0,255,100);
	sliderColSetNum.position(alphaColSetNum.position().x-140,alphaColSetNum.position().y-4);
	colorMenu.child(sliderColSetNum);sliderColSetNum.input(changeColSetNumA);
	anumColSetNum = createInput('100','number');anumColSetNum.size(38);
	anumColSetNum.elt.max = 255;anumColSetNum.elt.min = 0;
	anumColSetNum.position(alphaColSetNum.position().x-5,alphaColSetNum.position().y-alphaColSetNum.height-6);
	colorMenu.child(anumColSetNum);anumColSetNum.changed(changeColSetNumA);
	
	saveColSet = createElement('label','save');saveColSet.position(10,numA.position().y);
	saveColSet.style('padding-left','2px');saveColSet.style('padding-right','2px');
	saveColSet.style('background-color','grey');
	colorMenu.child(saveColSet);
	loadColSet = createElement('label','load');loadColSet.position(60,numA.position().y);
	loadColSet.style('padding-left','2px');loadColSet.style('padding-right','2px');
	loadColSet.style('background-color','grey');
	colorMenu.child(loadColSet);
	nameColSet = createInput();nameColSet.size(85,14);
	nameColSet.position(5,repColSetNum.position().y-2);
	colorMenu.child(nameColSet);

	sliderR.input(changeColor);
	numR.changed(changeColor);
	sliderG.input(changeColor);
	numG.changed(changeColor);
	sliderB.input(changeColor);
	numB.changed(changeColor);
	sliderA.input(changeColor);
	numA.changed(changeColor);
	pipette.mouseClicked(pickColor);
	colorBtn.mousePressed(dragMenuOn);
	colorBtn.mouseReleased(dragMenuOff);
	colorBtn.isDrag = false;
	colorBtn.unitedF = [0,0];
	colorBtn.isUnited = false;
	colorBtn.menu = colorMenu;

//				TOOLS TAB
	toolsBtn = createButton("Tools");
	toolsBtn.position(420,surf.position().y);
	toolsBtn.mouseClicked(showMenu);
	toolsMenu = createDiv("");
	toolsMenu.style('background-color','yellowgreen');
	toolsMenu.position(toolsBtn.position().x,toolsBtn.position().y+toolsBtn.height);
	toolsMenu.size(300,120);
	toolsRadio = createRadio();toolsRadio.style('background-color','red');
	toolsRadio.option("Pen");
	tSize = createElement('label',"size");tSize.style('background-color','white').elt.style.padding = "2px";
	sizeLabel = createElement('label','');
	pSize = createSlider(1,10,5);
	toolsRadio.option("None");
	toolsRadio.option("Line");
	toolsRadio.option("Fill");
	toolsRadio.option("Erase");
	toolsRadio.style('width','60px');
	toolsMenu.child(toolsRadio);
	toolsMenu.child(tSize);
	toolsMenu.child(sizeLabel);
	toolsMenu.child(pSize);
	tSize.position(toolsRadio.position().x+toolsRadio.width,toolsRadio.position().y);
	toolsRadio.changed(eraser);
	sizeLabel.elt.textContent = '-'.repeat(20/10*pSize.value()-1)+pSize.value()+'-'.repeat(20-(20/10*pSize.value()));
	pSize.position(tSize.position().x + 40,tSize.position().y);pSize.size(107,21);pSize.style('opacity','0');
	sizeLabel.position(pSize.position().x-1,pSize.position().y);
	sizeLabel.style('background-color','darkblue');sizeLabel.style('color','white');
	penTypeRadio = createRadio();penTypeRadio.option('simple');penTypeRadio.option('pmouse');penTypeRadio.option('shot');
	penTypeRadio.position(tSize.position().x,pSize.height);
	toolsMenu.child(penTypeRadio);
	penXY = createRadio();penXY.option("CORNER");penXY.option("CENTER");penXY.selected('CORNER');
	penXY.position(penTypeRadio.position().x+6,penTypeRadio.size().height+penTypeRadio.position().y);
	toolsMenu.child(penXY);
	pSize.input(setPenSize);
	penXY.changed(penXYset);
	toolsStep_ = createElement('label','---');toolsStep_.style('background-color','white');
	toolsStep_.position(pSize.position().x+pSize.width/1+8,pSize.position().y);
	toolsMenu.child(toolsStep_);
	toolsStep = createElement('label','$');
	toolsStep.position(pSize.position().x+pSize.width/1+8,pSize.position().y);
	toolsStep.style('padding-left','4px');toolsStep.style('padding-right','4px');
	toolsStep.style('outline-width','1px');toolsStep.style('outline-offset','-1px');toolsStep.style('outline-style','solid');
	toolsMenu.child(toolsStep);
	stepSize = createInput('1','number');stepSize.size(40,12);
	stepSize.elt.max = 64;stepSize.elt.min = 1;
	stepSize.position(toolsStep.position().x+toolsStep.size().width+6,toolsStep.position().y);
	toolsMenu.child(stepSize);
	toolsStep.mouseClicked(stepTool);
	toolsBtn.mousePressed(dragMenuOn);
	toolsBtn.mouseReleased(dragMenuOff);
	toolsBtn.isDrag = false;
	toolsBtn.unitedF = [0,0];
	toolsBtn.isUnited = false;
	toolsBtn.menu = toolsMenu;
	
//					REPLACER TAB
	replacerBtn = createButton('Replacer');
	replacerBtn.position(500,surf.position().y);
	replacerMenu = createDiv("");replacerMenu.size(220,120);
	replacerMenu.style('background-color','orange');
	replacerMenu.position(replacerBtn.position().x,replacerBtn.position().y+replacerBtn.height);

	repColors[0] = [];
	repColors[0][0] = createElement('label','');repColors[0][0].position(10,50);
	repColors[0][0].elt.style.width = "40px";repColors[0][0].elt.style.height = "40px";
	replacerMenu.child(repColors[0][0]);
	repColors[0][0].mouseClicked(pickColToRep);
	
	repColors[0][5] = createElement('label','');repColors[0][5].position(170,50);
	repColors[0][5].elt.style.width = "40px";repColors[0][5].elt.style.height = "40px";
	replacerMenu.child(repColors[0][5]);
	
	repColors[0][1] = createElement('label','R--------------------');repColors[0][1].position(49,40);
	repColors[0][1].elt.style.width = "122px";repColors[0][1].elt.style.height = "18px";
	repColors[0][1].style('background-color','yellow');repColors[0][1].style('opacity','0.5');
	replacerMenu.child(repColors[0][1]);repColors[0][1].mouseWheel(wheelRepCol);
	repColors[0][1].elt.onmousemove = changeRepRGBA;
	repColors[0][1].elt.r = 'R-';
	
	repColors[0][2] = createElement('label','G--------------------');repColors[0][2].position(49,60);
	repColors[0][2].elt.style.width = "122px";repColors[0][2].elt.style.height = "18px";
	repColors[0][2].style('background-color','yellow');repColors[0][2].style('opacity','0.5');
	replacerMenu.child(repColors[0][2]);repColors[0][2].mouseWheel(wheelRepCol);
	repColors[0][2].elt.onmousemove = changeRepRGBA;
	repColors[0][2].elt.r = 'G-';

	repColors[0][3] = createElement('label','B--------------------');repColors[0][3].position(49,80);
	repColors[0][3].elt.style.width = "122px";repColors[0][3].elt.style.height = "18px";
	repColors[0][3].style('background-color','yellow');repColors[0][3].style('opacity','0.5');
	replacerMenu.child(repColors[0][3]);repColors[0][3].mouseWheel(wheelRepCol);
	repColors[0][3].elt.onmousemove = changeRepRGBA;
	repColors[0][3].elt.r = 'B-';
	
	repColors[0][4] = createElement('label','A--------------------');repColors[0][4].position(69,100);
	repColors[0][4].elt.style.width = "122px";repColors[0][4].elt.style.height = "18px";
	repColors[0][4].style('background-color','yellow');repColors[0][4].style('opacity','0.5');
	replacerMenu.child(repColors[0][4]);repColors[0][4].mouseWheel(wheelRepCol);
	repColors[0][4].elt.onmousemove = changeRepRGBA;
	repColors[0][4].elt.r = 'A-';
	
	repColors[0][6] = createElement('label','res');repColors[0][6].position(197,repColors[0][4].position().y);
	repColors[0][6].style('background-color','white');
	repColors[0][6].style('padding-left','1px');repColors[0][6].style('padding-right','1px');
	replacerMenu.child(repColors[0][6]);repColors[0][6].elt.col = [];
	repColors[0][6].mousePressed(resetColor);

	repColors[0][0].elt.style.backgroundColor = 'black';
	repColors[0][5].elt.style.backgroundColor = 'black';
	repColors[0][5].elt.onmousedown = newColor;
	repColors[0][5].elt.newColor = newColor;
	
	replacerDiv = createElement('label','');replacerDiv.elt.style.backgroundColor = 'orange';
	replacerDiv.elt.style.width = '220px';replacerDiv.elt.style.height = '0px';
	replacerDiv.elt.zH = 149;
	replacerDiv.position(replacerMenu.position().x,replacerMenu.position().y+replacerMenu.height);

	//fromColor1.style("background-image", "linear-gradient(to right,"+
	//	color(curColor[0],curColor[1],curColor[2])+" 50%,"+ color(curColor)+" 50%)");
	
	inputColRep = createInput('0','number');inputColRep.size(42,12);
	inputColRep.elt.max = 255;inputColRep.elt.min = 0;
	inputColRep.elt.style.zIndex = +1;inputColRep.hide();
	replacerMenu.child(inputColRep);
	inputColRep.changed(useRepColNum);
	inputColRep.elt.onblur = hideRepColNum;
	
	multiRepCol = createImg('icos/replacerico.png','multi replacer');
	multiRepCol.position(10,5);
	replacerMenu.child(multiRepCol);
	plusRepCol = createElement('label','+');plusRepCol.position(180,25);//180,25
	plusRepCol.elt.style.backgroundColor = 'white';
	plusRepCol.elt.style.paddingLeft = '3px';plusRepCol.elt.style.paddingRight = '3px';
	plusRepCol.elt.style.borderWidth = '1px';plusRepCol.elt.style.borderStyle = 'solid';
	replacerMenu.child(plusRepCol);
	minusRepCol = createElement('label','-');minusRepCol.position(22,95);//22,95
	minusRepCol.elt.style.backgroundColor = 'white';
	minusRepCol.elt.style.paddingLeft = '4px';minusRepCol.elt.style.paddingRight = '4px';
	minusRepCol.elt.style.borderWidth = '1px';minusRepCol.elt.style.borderStyle = 'solid';
	replacerMenu.child(minusRepCol);
	plusRepCol.mouseClicked(addRepCol);minusRepCol.mouseClicked(delRepCol);
	
	liveColRep = createElement('label','Live');
	liveColRep.elt.style.backgroundColor = 'white';liveColRep.position(180,5);
	liveColRep.elt.style.paddingRight = '2px';liveColRep.elt.style.paddingLeft = '2px';
	replacerMenu.child(liveColRep);
	resetColRep = createElement('label','Reset');
	resetColRep.elt.style.backgroundColor = 'white';resetColRep.position(138,5);
	resetColRep.elt.style.paddingRight = '2px';resetColRep.elt.style.paddingLeft = '1px';
	replacerMenu.child(resetColRep);
	autoColRep = createElement('label','Auto');
	autoColRep.elt.style.backgroundColor = 'white';autoColRep.position(99,5);
	autoColRep.elt.style.paddingRight = '2px';autoColRep.elt.style.paddingLeft = '2px';
	replacerMenu.child(autoColRep);
	numsColRep = createElement('label','Nums');
	numsColRep.elt.style.backgroundColor = 'white';numsColRep.position(55,5);
	numsColRep.elt.style.paddingRight = '2px';numsColRep.elt.style.paddingLeft = '1px';
	replacerMenu.child(numsColRep);
	numsColRep.mousePressed(turnResetAutoLive);
	autoColRep.mousePressed(turnResetAutoLive);
	resetColRep.mousePressed(turnResetAutoLive);
	liveColRep.mousePressed(turnResetAutoLive);
	
	repSlider = createSlider(0,0,0);repSlider.elt.step = 1;
	repSlider.style("transform-origin","0%");
	repSlider.style("transform","rotate(90deg)");
	repSlider.position(220,0);repSlider.input(replacerSlide);
	replacerMenu.child(repSlider);
	hideRepDiv = createElement('label','h');hideRepDiv.style('background-color','white');
	hideRepDiv.elt.style.paddingRight = '2px';hideRepDiv.elt.style.paddingLeft = '2px';
	hideRepDiv.elt.style.borderWidth = '1px';hideRepDiv.elt.style.borderStyle = 'solid';
	hideRepDiv.position(minusRepCol.position().x-14,minusRepCol.position().y);
	replacerMenu.child(hideRepDiv);hideRepDiv.mousePressed(hideReplacerDiv);
	pinRepDiv = createElement('label','p');pinRepDiv.style('background-color','white');
	pinRepDiv.elt.style.paddingRight = '2px';pinRepDiv.elt.style.paddingLeft = '2px';
	pinRepDiv.elt.style.borderWidth = '1px';pinRepDiv.elt.style.borderStyle = 'solid';
	pinRepDiv.position(plusRepCol.position().x+17,plusRepCol.position().y);
	replacerMenu.child(pinRepDiv);pinRepDiv.mousePressed(turnResetAutoLive);	
	
	replacerBtn.mouseClicked(showMenu);
	replacerBtn.mousePressed(dragMenuOn);
	replacerBtn.mouseReleased(dragMenuOff);
	replacerBtn.isDrag = false;
	replacerBtn.unitedF = [0,0];
	replacerBtn.isUnited = false;
	replacerBtn.menu = replacerMenu;


//				LAYERS TAB
	layersBtn = createButton('Layers');
	layersBtn.position(700,surf.position().y);
	layersMenu = createDiv('');layersMenu.size(150,30);
	layersMenu.style('background-color','violet');
	layersMenu.position(layersBtn.position().x,layersBtn.position().y+layersBtn.height);
	plusLayer = createElement('label','[+]');plusLayer.style('background-color','white');
	plusLayer.elt.style.paddingRight = '1px';plusLayer.elt.style.paddingLeft = '1px';
	plusLayer.position(5,5);plusLayer.mousePressed(addLayer);
	layersMenu.child(plusLayer);
	minusLayer = createElement('label','[-]');minusLayer.style('background-color','white');
	minusLayer.elt.style.paddingRight = '2px';minusLayer.elt.style.paddingLeft = '2px';
	minusLayer.position(30,5);minusLayer.mousePressed(minusLayerOn);
	layersMenu.child(minusLayer);
	layersList = createElement('label','');layersList.size(150);
	layersList.position(layersMenu.position().x,layersMenu.position().y+layersMenu.height);
	layersList.elt.style.backgroundColor = 'olive';
	layersSlider = createSlider(0,0,0);layersSlider.elt.step = 1;
	layersSlider.style("transform-origin","0%");layersSlider.style("transform","rotate(90deg)");
	layersSlider.position(150,-10);
	layersMenu.child(layersSlider);
	layersInput = createInput('','hidden');layersInput.size(40);
	layersList.child(layersInput);layersInput.elt.onblur = hideLayersInput;
	
	layersBtn.mouseClicked(showMenu);
	layersBtn.mousePressed(dragMenuOn);
	layersBtn.mouseReleased(dragMenuOff);
	layersBtn.isDrag = false;
	layersBtn.menu = layersMenu;
	

	addLayer();
	layers[0][1].elt.onmousedown();


//				OPTIONS TAB
	optionsBtn = createButton("Options");
	optionsBtn.position(1000,surf.position().y);
	optionsMenu = createDiv('');optionsMenu.size(10,10);
	optionsMenu.style('background-color','purple');
	optionsMenu.position(optionsBtn.position().x,optionsBtn.position().y+optionsBtn.height);
	
	optionsBtn.mouseClicked(showMenu);
	optionsBtn.mousePressed(dragMenuOn);
	optionsBtn.mouseReleased(dragMenuOff);
	optionsBtn.isDrag = false;
	optionsBtn.menu = optionsMenu;
	
	
	unitedListChb = createCheckbox('List');unitedListChb.hide();
	unitedListChb.changed(menusToList);
//				Call grid initialization
	setGrid();
	gridStep.input(resizeGrid);
	pGrid.elt.style.pointerEvents = 'none';
//				Mouse coords numbers
	mouseCoords = createSpan();
	mouseCoords.style('font-size','12px');
//				Call drawing
	//surf.mousePressed(drawingOnCanvas);
	//surf.mouseMoved(drawingOnCanvas);
	//pGrid.mousePressed(drawingOnCanvas);
	//pGrid.mouseMoved(drawingOnCanvas);
	//surf.mouseReleased(stopDrawingCanvas);
	//pGrid.mouseReleased(stopDrawingCanvas);
//				Set classes
	fileBtn.addClass('MenuButtons');canvasBtn.addClass('MenuButtons');colorBtn.addClass('MenuButtons');toolsBtn.addClass('MenuButtons');replacerBtn.addClass('MenuButtons');
	menuBtns.push(fileBtn,canvasBtn,colorBtn,toolsBtn,replacerBtn);
	toolsRadio.class('radios');
//				Set z-Index
	surf.elt.style.zIndex = '-100';pGrid.elt.style.zIndex = '1';
	widthBtn.elt.style.zIndex = '2';heightBtn.elt.style.zIndex = '2';
	fileBtn.elt.style.zIndex = '2';fileMenu.elt.style.zIndex = '2';
	canvasBtn.elt.style.zIndex = '2';canvasMenu.elt.style.zIndex = '2';
	colorBtn.elt.style.zIndex = '2';colorMenu.elt.style.zIndex = '2';
	toolsBtn.elt.style.zIndex = '2';toolsMenu.elt.style.zIndex = '2';
	replacerBtn.elt.style.zIndex = '3';replacerMenu.elt.style.zIndex = '3';replacerDiv.elt.style.zIndex = '3';
	layersBtn.elt.style.zIndex = '4';layersMenu.elt.style.zIndex = '4';layersList.elt.style.zIndex = '4';

}